# Universal LM-Assisted Research & Software Project SOP
_Version: 2026-03-29-r3 (lab-grade universal edition)_
_Supersedes: PROJECT_WIDE_COMPREHENSIVE_SOP_2026-03-29au-r2_
_Scope: Any LM-assisted research or software project — not project-specific by default_

---

## 0. Purpose & Scope

This SOP governs any long-horizon research or software project conducted with the assistance of language models (LMs). It is written to be **universal** — applicable to any project — while carrying forward all hard-won doctrine from Singularity Works / Forge / CIL / KarnOS / TQ2 development.

It prevents:
- Chat drift, compaction loss, duplicated ideas, forgotten requirements
- Disconnected research, silent assumption lock-in
- Fake progress, premature closure, evidence debris
- Untracked doctrine changes
- Evaluation theater masquerading as rigor
- Substrate overclaiming before empirical foothold exists
- Process debt accumulating until the project dissolves

It is the **operating system** of the lab, not a checklist.

---

## 1. Foundational Control Law

### 1.1 The Master Loop

**PROBE → DERIVE → EMBODY → VERIFY → RECURSE**

Every meaningful unit of work in this lab runs through these five stages. None may be skipped. None may be reordered.

```
PROBE     — Interrogate the system until you expose actual structure,
            failure modes, hidden dependencies, and latent signal.
            Not vibes. Not aesthetics. Not surface plausibility.

DERIVE    — Translate probe results into a falsifiable interpretation.
            State: what changed, what did not, what this now implies,
            what assumption got stronger or weaker.
            If you cannot write a falsifiable claim, you have not derived yet.

EMBODY    — Instantiate the derivation in: code, architecture, runtime,
            readout, memory policy, scheduler, benchmark, document, ontology.
            Embodiment is not "write it down." It is "make it runnable or testable."

VERIFY    — Check whether embodiment cashes out the derivation.
            Rerun. Compare. Diff. Measure. Record residuals.
            Update docs. Update incumbent vs open seams.
            Do NOT let embody → recurse happen without this brake.

RECURSE   — Repeat forward AND backward. If a new result meaningfully
            changes interpretation, rerun earlier seams under the new view.
```

The VERIFY stage is the hard brake that prevents mythology. Do not skip it.

### 1.2 The Outer Shadow-Control System

The project's persistent memory lives in a **shadow-doc control layer**. These are not notes. They are the project's immune system and lab notebook combined.

Mandatory document set:

1. **This SOP** — loaded first, always
2. **Trace Matrix** — master operational table of requirements and status
3. **Research Crosswalk** — compounding research indexed by seam, not by paper
4. **Addendum** — fast delta for newest findings
5. **Maintenance Note** — update discipline record
6. **Revisit Ledger** — what must be replayed, under what conditions, and why
7. **Doctrine Snapshot** — current state of all promoted beliefs
8. **Extraction Docs** — zero-loss OIE+ELT+Systematic+DEFNLP passes over uploads
9. **White Paper / Basis Doc** — running synthesis of the project's load-bearing core
10. **Evaluation Log** — honest scorecard updated after each wave

### 1.3 First Instruction for Any LM Session

Before doing anything substantive:

> Treat this project as a **lab**, not a casual conversation. You are resuming a long-horizon research and build process with persistent shadow docs, artifact corpus, experiment history, doctrine snapshots, revisit ledgers, and recursive process rules.
>
> **Do not assume memory from chat context is sufficient.**

Then execute the mandatory rehydration sequence:

1. This SOP (load first)
2. Current trace matrix + crosswalk + addendum + maintenance note
3. Latest next-steps / work queue doc
4. Latest SOP cycle update
5. Latest revisit ledger + supplement
6. Ontology / doctrine snapshot
7. Relevant extraction docs / corpus captures
8. Relevant experiment reports for the active seam

---

## 2. Governing Rules (Non-Negotiable)

### Rule 1 — Nothing locks in early
No architecture, variable, doctrine, or result becomes final because it is currently winning.

### Rule 2 — Best current is not final
Incumbent means: best current operational baseline, still provisional, must survive future replay.

### Rule 3 — No silent overwrite
Update doctrine by delta, not by amnesia. Every change is recorded.

### Rule 4 — No orphan insight
If a finding matters, it must land in a shadow doc, spec, report, doctrine snapshot, or revisit ledger. If it does not land, it does not count.

### Rule 5 — No fake progress
A long discussion is not advancement unless: docs moved, artifacts were produced, or a seam was genuinely narrowed.

### Rule 6 — No disconnected research
Research must change build pressure, doctrine, ordering, or active seams. Otherwise it is background, not advancement.

### Rule 7 — No feature-only planning
The QA/evidence spine must advance with the feature/build spine. They are not separable.

### Rule 8 — No hidden uncertainty
If something is partial, residual, speculative, not yet wired, or not yet validated — say so explicitly in the record.

### Rule 9 — No closure by one failed framing
A failed implementation kills that framing, not necessarily the variable class.

### Rule 10 — No single-source sufficiency
Do not treat any one of: current thread, recent memory, one upload, one report, one benchmark, one paper, one model's opinion as sufficient by itself.

### Rule 11 — No evaluation theater
Identical results across structurally different conditions is a signal of implementation failure, not a negative result. Audit before accepting as data.

### Rule 12 — No architecture widening without seam resolution
Do not widen the architecture while central failure modes remain unresolved. Freeze and audit first.

### Rule 13 — No substrate claims without empirical foothold
A substrate idea with no empirical result is theory. Record it as theory. Do not confuse it with evidence.

### Rule 14 — No project collapse into one undifferentiated mass
When a project contains distinct workstreams (e.g., substrate-A vs. substrate-B; weight-format vs. reasoning-runtime), they must be scored separately. Mixing their evidence produces category errors.

### Rule 15 — No process automation debt forever
Manual doc-discipline eventually rots. Every project should have a horizon for moving key process steps into formal automation. Name the debt explicitly; do not let it accumulate silently.

---

## 3. Core Vocabulary

### 3.1 Epistemic Status Terms
- **Open**: not explored enough to justify closure
- **Active**: currently under investigation
- **Incumbent**: best current result; baseline to beat; still provisional
- **Collapsed**: only after variable neighborhood has been sufficiently exhausted under the closure standard
- **Promotable**: finding meets promotion criteria but not yet formally integrated
- **Provisional**: integrated into doctrine but still subject to replay
- **Stable**: survived recursive replay; treated as hard constraint

### 3.2 Process Terms
- **Zero-loss extraction**: preserve → extract → normalize → post-process → synthesize; no signal discarded before interpretation
- **Loop+**: external science/buzzword/isomorph research loop layered over the internal loop
- **Shadow layer**: the persistent project-memory/control document system
- **Monotonic atomicity**: new findings recurse backward through earlier seams
- **Isomorph predator**: hunt structural equivalents across domains
- **QA/evidence spine**: proof, risk, gate, assurance chain advancing with the build spine
- **Evaluation theater**: a structurally non-distinct test reporting non-distinct results, treated as meaningful data

### 3.3 Architecture Terms (Carry-forward from Forge/CIL/TQ2 Lineage)
- **Genome**: the capsule database that IS the generator of gate logic, transformation axioms, and detection strategies — not a parallel catalog
- **Radical**: a semantic family kernel; when multi-modal centroid alignment is achieved, the Radical IS the centroid
- **SBUF (Session Buffer)**: volatile, ephemeral, fast-write working memory — hippocampal analog; clears after consolidation
- **EPMEM (Episodic Memory)**: durable witness ledger with bi-temporal timestamps
- **SMEM (Semantic Memory)**: governed stable memory — slowly updated, epistemic state machine (WITNESS→HYPOTHESIS→PROVISIONAL→STABLE)
- **Contradiction Graph**: explicit negative epistemics — never silently dropped
- **FactBus**: typed shared blackboard for gate-to-gate communication within a session
- **Switchboard**: derivation engine (not router) — compound facts emerge from PropagationRules over gate findings
- **Dialectic loop**: REASONER + CODER adversarial pair — debate → synthesis → audit
- **IRIS mode**: escalation path when IR confidence is low — LLM infers source/sink specs as DynamicCapsule
- **TQ2**: the canonical ternary plane/block discrete geometric substrate (current normative weight/inference architecture in the KarnOS/weight lineage)
- **K2**: accumulated-inference fast lane for the TQ2/CIL runtime
- **K3**: meta/checkpoint/cold-state lane — NOT live control

---

## 4. Closure Standard

A path is only considered **collapsed** when ALL of the following have happened:

1. Direct test
2. Nearby-combination test
3. Inversion / wrong-looking test
4. Recursive replay after later findings
5. Still no meaningful gain beyond redundancy

Neutral once is not dead. Bad framing is not variable closure. Silence is not evidence.

---

## 5. Session SOP

### 5.1 At Session Start

Load in order: SOP → doc set → next steps → SOP cycle update → revisit ledger → ontology/doctrine → extraction docs → active-seam reports.

Classify session as: research / consolidation / spec / build / audit / extraction-ingest / evaluation.

State explicitly:
- What is the incumbent baseline?
- What seams are currently open?
- What does the last verified result say?
- What would falsify the current hypothesis?

### 5.2 After Each Major Change

Update: matrix (if requirement/status changed), crosswalk (if research changed architecture), addendum (if new high-value findings), maintenance note (if discipline changed), next-steps (if queue changed), doctrine snapshot (if incumbent/open interpretation changed), revisit ledger (if something must be replayed).

### 5.3 Before Implementation

Check: matrix reflects real build order, specs exist or are truly unnecessary, research-backed refinements are promoted, QA/evidence spine is represented.

### 5.4 After Implementation

Record: implemented/partial/missing, new evidence, gate state, residuals, simplification opportunities, new risks, recursive replay obligations.

---

## 6. Evaluation Discipline

### 6.1 Core Requirements for Every Experiment

Every experiment must produce:
- Spec (what was tested, what was controlled, what varied)
- Results (raw or summary)
- Report (interpretation, confidence, limitations)
- Doctrine implication (what this changes in the build or belief system)
- Updated next steps

Every experiment must answer:
- What variable was actually tested?
- What nearby variables remain open?
- What assumption strengthened or weakened?
- What must now be replayed recursively?

### 6.2 Evaluation Quality Standards

**Structural distinctness requirement**: If two experimental conditions produce identical results, investigate whether the conditions are actually distinct before accepting as data. Identical results from non-identical conditions is almost always an implementation error, not a scientific negative.

**External baseline requirement**: Every meaningful benchmark needs at least one external comparator (a minimal learned baseline, a known prior method, or a naive predictor). Without this, you do not know if you are near the task ceiling or the substrate ceiling.

**Scorecard separation requirement**: When a project contains distinguishable workstreams, maintain separate scorecards. Evidence for workstream A is not automatic evidence for workstream B.

**Orphaned-finding requirement**: After every extraction or evaluation pass, explicitly list high-value findings that could be lost in the main narrative. These are the most important signal to preserve.

### 6.3 Evaluation Loop

The evaluation loop mirrors the master loop:

```
PROBE an experimental condition
DERIVE a falsifiable prediction
EMBODY in executable code/protocol
VERIFY with data and external comparison
RECURSE with the updated belief
```

Do not let evaluation become a ritual. If a benchmark consistently does not change doctrine, either the benchmark is wrong or the variable is dead.

### 6.4 Minimum Experiment Classes (Forge/Code-Intelligence Specific)

- Baseline contrast: good-path GREEN, bad-path RED, remediated-path GREEN
- Security path: pre-remediation RED, post-remediation GREEN
- Self-audit: the system must audit its own source with the same standard applied outward
- Assault pass: false positive wave (clean code → all GREEN), false negative wave (known failures → all RED)
- Recursive replay after architectural changes

**Zero-False-Green Constraint (Hard)**: A forge that says "safe" when something is dangerous is worse than no forge. Zero false greens is a hard architectural invariant, not a goal.

---

## 7. Zero-Loss Upload & Extraction SOP

All uploads are treated as lab evidence by default. Every serious upload should be processed through all five phases.

### Phase A — ELT Ingest
Preserve raw files, create manifest, hash artifacts, map corpus, do not destroy raw structure before interpretation.

### Phase B — OIE Extraction
Normalize: entities, relations, claims, process patterns, dependencies, doctrine changes, benchmark implications.
- Coreference resolution: all mentions of the same entity resolve to a single record
- Triple extraction: every stated fact → (Subject, Predicate, Object)

### Phase C — Standardized Extraction Matrix
For each meaningful claim:
- Source artifact
- Claim
- Evidence strength
- Doctrine effect
- Status
- Next action

### Phase D — DEFNLP-Style Post-Processing
Rescue: orphan signal, contradictions, hidden dependencies, baseline errors, ambiguous terminology, facts that would otherwise vanish in summary.

Specifically check for:
- Self-referential patterns (system flagging its own patterns)
- Assumption bleed (implementation language or domain infecting analysis assumptions)
- Conditional paths that silently drop signal
- Capability routing mismatches
- **Evaluation theater**: non-distinct conditions producing identical results

### Phase E — Control-Layer Integration
Promote only what is: repeated, load-bearing, architecture-shaping, research-validated, implementation-relevant, or process-critical.

### Phase F — Output Package
Each serious upload should yield: manifest, extraction doc, triples/facts table, standardized matrix, post-process synthesis, package zip.

---

## 8. Research SOP (Loop+)

Loop+ is the external science / discovery / buzzword / isomorph research loop layered over the internal loop.

### 8.1 Loop+ Stages
1. Primary-source pass
2. Discovery pass (cross-domain structural equivalents)
3. Buzzword / fast-signal pass
4. Isomorph-predator pass
5. Native ontology translation
6. Control-layer update
7. Experiment pressure (what does this research change in the build?)
8. Recursive replay

### 8.2 Research Rules
- Group findings by seam, not by paper
- Prefer representative sources over giant citation dumps
- Record what the seam changes in the build
- Record uncertainty honestly
- Do not collect trivia; do not import jargon without translation

### 8.3 Source Buckets
**Primary science:**
arXiv, bioRxiv, TechRxiv (IEEE), SSRN, Zenodo, OSF Preprints, medRxiv, ChemRxiv, Semantic Scholar, CORE

**Discovery (cross-domain):**
cognitive neuroscience (CLS, FEP, predictive coding), game engine architecture (ECS), agent memory systems, security research (IRIS, CodeQL, Joern), representation learning, memory compression, bi-temporal knowledge graphs, discrete optimization, information geometry

**Buzzword / fast-signal:**
Ars Technica, Wired, Hacker News, GamersNexus (hardware substrate signal), The Verge, TechCrunch (startup/product signal), AnandTech, TechPowerUp

**Internal:**
Uploaded captures, extraction docs, shadow docs, experiment reports, doctrine snapshots

### 8.4 Isomorphic Hunting Domains
Map equivalent structures across: signal processing, graphics, sound, memory, routing, control systems, runtime assurance, retrieval, compression, cognitive neuroscience, game engine ECS, formal verification, statistical mechanics, information theory.

Known confirmed isomorphisms (from Forge/CIL/TQ2 lineage):
- Temperature ↔ Distortion budget (centroid tightness)
- IRIS architecture ↔ Forge architecture (LLM→formal→LLM = heuristic→gate→LLM)
- CLS hippocampus ↔ SBUF (fast/slow memory at different scales)
- NEAL R-pipeline ↔ Switchboard L0-L5 (sequential confidence gates)
- PatternIR radicals ↔ NEAL-CORE radicals (same abstraction invented twice)
- TQ2 whole-plane + blockwise inference ↔ global vs. local invariant decomposition (standard computer vision pattern)
- K2 accumulation ↔ episodic memory consolidation (structure builds over steps)

---

## 9. Reading & Extraction Discipline

### 9.1 No Skim Rule
If a corpus is designated important, read it deeply. Do not skim and report vibes.

### 9.2 Pattern-Over-Term Rule
Do not only search for terms. Search for: structures, motifs, isomorphisms, repeated process patterns, same-shape ideas across different labels.

### 9.3 Cross-Domain Rule
Map equivalent structures across all domains. The isomorphisms section of the extraction doc is where this lives.

### 9.4 Ground-Truth Rule
Trust artifacts over recollection, extraction over vibes, docs over narrative.

### 9.5 Coreference Resolution Rule
All mentions of the same entity resolve to a single record before claims are extracted. Ambiguous pronouns are a signal of potential coreference error.

### 9.6 Self-Evaluation Rule
After every corpus pass, apply the same extraction logic to the LM's own responses. Look for: overclaiming, underclaiming, vague language where precision is needed, framing that drifts from the evidence.

---

## 10. Doctrine Promotion SOP

A finding is **promotable** when it is: repeated, load-bearing, architecture-shaping, research-supported, implementation-relevant, or process-critical.

A finding should stay **provisional** if it is: decorative, speculative with no build consequence, redundant, not yet differentiated from preference, not yet recursively replayed.

A finding should be **quarantined** if it is: overclaiming, not earning its complexity, based on structurally non-distinct evaluation, or derived from a single non-validated pass.

---

## 11. Compaction / Context-Loss Recovery Procedure

1. Stop widening
2. Load this SOP
3. Load current trace matrix + crosswalk + addendum + maintenance note
4. Load latest next steps
5. Load latest SOP cycle update
6. Load latest revisit ledger / supplement
7. Load ontology / doctrine snapshot
8. Load relevant extraction docs and active-seam reports
9. Re-state: incumbent baseline, open seams, recently promoted findings, what is actually closed vs still open
10. Verify: no assumption bleed, no architecture widening without seam resolution, no evaluation theater in recent results
11. Only then resume

---

## 12. Project Separation Rules

### 12.1 Workstream Separation
When a project contains distinguishable workstreams, maintain separate scorecards. Do not use evidence from one to silently advance claims in another.

Example pattern (from TQ2/CIL lineage):
- Project A (weight/distillation substrate): empirical foothold required before broad claims
- Project B (reasoning/runtime substrate): evidence separate from A

### 12.2 Implementation Language ≠ Analysis Domain
A system's implementation language does not determine the domain it analyzes. Any code path that assumes the analysis target matches the implementation context is an architectural error.

### 12.3 Substrate Claims ≠ Empirical Results
An interesting substrate with no empirical result is theory. Record it as theory until it earns empirical ground.

---

## 13. LLM Danger-Minimization Rules

The LLM must assume these failure modes are always possible:
- Context compaction, partial memory loss, silent loss of earlier decisions
- Overcompression of nuanced findings
- False confidence from recent context only
- Treating incumbent baselines as closed doctrine
- Evaluation theater: treating non-distinct experimental conditions as meaningful comparative data
- Substrate overclaiming: treating a promising substrate direction as a validated result
- Scope collapse: letting two distinct workstreams' evidence bleed into each other

To reduce loss:
- Reload the control layer first
- Prefer artifacts over memory; extraction docs over recollection
- Prefer matrix/crosswalk/addendum over narrative recall
- Surface uncertainty explicitly
- Never silently overwrite prior doctrine — update by diff
- Evaluate your own response using the same extraction discipline applied to external sources

---

## 14. Benchmark / Baseline SOP

### 14.1 Never Trust One Baseline
Use the correct floor for the task family.

### 14.2 Separate Benchmark Conditions
Separate: bound-prototype, estimated-prototype, no-prototype conditions explicitly.

### 14.3 External Comparator Requirement
Every benchmark needs at least one external comparator. Without it, you do not know whether you are near the task ceiling or the substrate ceiling.

### 14.4 Domain Split Rule
Do not assume results transfer cleanly across domains. If text behaves differently from structured-motif domains, branch doctrine.

### 14.5 No Evaluation Theater
Two structurally non-distinct conditions producing identical results is a likely implementation error. Audit before accepting as data.

---

## 15. Architectural Doctrine (Carry-Forward from Forge/CIL Lineage)

These are stable promoted findings from the Singularity Works research lineage. Applicable to any project with similar architectural concerns.

### 15.1 Layered Memory is 1/3 of Output Quality
A flat event log accumulates noise. Any context system must implement at minimum:
- SBUF (ephemeral, fast-write)
- EPMEM (durable, bi-temporal)
- SMEM (governed semantic, slow-update)
- Contradiction Graph (explicit negative epistemics, never dropped)

### 15.2 Genome as Generator, Not Catalog
Any rule/gate/strategy system that lives outside the core capsule/genome structure is technical debt on day one. The genome must be the generator of gate logic, not a parallel catalog.

### 15.3 The Three-Role Cognitive Trinity
In a system with memory, inference, and permissibility enforcement:
- What is known (memory substrate)
- What is possible (inference/generation engine)
- What is permissible (enforcement/audit layer)

These are co-equal roles. Removing any one eliminates a distinct epistemic function.

### 15.4 Isomorphic Discoveries Preserved as Doctrine

| Isomorphism | Meaning |
|---|---|
| Temperature ↔ Distortion budget | Both control centroid tightness |
| IRIS architecture ↔ Forge architecture | Dual convergence on same loop |
| CLS hippocampus ↔ SBUF | Same fast/slow computational structure at different scales |
| NEAL R-pipeline ↔ Switchboard L0-L5 | Sequential confidence gates, same architecture |
| PatternIR radicals ↔ NEAL-CORE radicals | Same abstraction invented twice — confirms correctness |
| TQ2 strata ↔ local+global invariant decomposition | Both encode the principle that task structure determines operator family |
| K2 accumulation ↔ episodic memory consolidation | Structure builds over steps |

---

## 16. TQ2/CIL/Forge Project-Specific State (2026-03-29)

_This section is project-specific context. For use when resuming the Singularity Works / Forge / CIL / KarnOS / TQ2 project. Override or replace for other projects._

### 16.1 Current System State

**The Forge:** v1.11, Python, 35 genome capsules, 34 detection strategies, 38/38 assault pass, 20/20 core hammer, self-audit 0 fail. Language-agnostic (Universal Semantic IR). Migrating to Rust ECS (cil-forge scaffold, 16 files, compiles clean).

**CIL:** ~140K LOC Rust, 19 crates. ForgeContext v4.0 wired (SBUF/EPMEM/SMEM/Contradiction). Key crates: cil-quantization (37K LOC, semantic_vq), cil-taint, cil-council (REASONER+CODER dialectic), cil-forge (hecs ECS scaffold).

**CIL Council v2.0:** REASONER (35B MoE) + CODER (7B) + GHOST (0.8B embedder) dialectic loop.

**TQ2 Weight Substrate:** Canonical discrete geometric substrate. RB-2R_v3 is the best current integrated runtime (97.12% T1, 100% T2/T3, 53.50% T4). K2 is the live fast lane. K3 is meta/checkpoint only.

**Bridge:** forge_bridge.py + CLAUDE.md + lcc.bat + setup.bat — Windows-native.

### 16.2 Top Priority Open Seams

**Immediate (blocking):**
- CIL-031: Workspace canonicalization — BLOCKING before widening
- cil-council self-scan Law 1 fix — P1

**TQ2/CIL Runtime:**
- Dual-head code audit (evaluation theater suspected)
- Structurally distinct route-aware readout
- Stepwise multi-path separability experiment
- z_MAYBE gate/drop experiment
- Dimension-selective readout
- LATENT_FINAL_ONLY rerun at larger N
- Text transform-family ablation
- External MLP baseline on T1–T4
- Toy distillation feasibility result (Project A)

**Forge:**
- Fixed-point multi-hop propagation
- Interprocedural field sensitivity
- Warrant-carrying assurance graph
- Grammar inference (PARSE radical family)
- Genome evolution from validated outcomes
- cilfsd 7 TODOs

### 16.3 Hard Constraints That Must Survive Every Session

- Zero false greens (hard architectural invariant)
- Genome IS the generator (not a parallel catalog)
- Language-agnostic analysis (no "unknown" state, no implementation-language assumption bleed)
- IR fallback unconditional (not gated on AST success)
- Bug bounty mode stays local (no cloud exposure of target code)
- TQ2 strata: separate to measure, compose to run
- K3 is meta/checkpoint only — do NOT revive as live control without multi-path evidence

### 16.4 Project Scorecard Split

**Project A — Weight/Distillation Substrate:**
Status: Theory only. No empirical foothold yet. Wave A1 (toy distillation result) is the gate to any broader claim.

**Project B — Reasoning/Runtime Substrate:**
Status: Real empirical signal. RB-2R_v3 confirmed. K2 accumulation confirmed. Current bottleneck: readout/disentangling.

---

## 17. Required Standing Assumptions

- Uploads are relevant lab evidence
- Zero-loss extraction is default
- Silence does not imply closure
- Process discipline is part of the architecture
- Research exists to pressure the build
- Docs are part of the runtime memory of the project process
- Every meaningful pass should leave artifacts behind
- The genome/rule-generator must remain the single source of truth
- Language-agnostic analysis is a hard requirement, not a roadmap item
- Layered memory is 1/3 of final output quality
- Evaluation theater is a real failure mode, not a minor data quality issue
- Substrate claims require empirical foothold before advancing beyond theory
- Manual process debt will eventually rot the project — name it, track it, close it

---

## 18. Minimum Required LM Reply Behavior

For project/lab/corpus replies, the LM should:
1. Reconnect to the control layer and project-specific context
2. State the current incumbent vs open seams
3. Avoid pretending uncertain things are settled
4. Cite relevant artifacts
5. Update the doc chain when there is a real delta
6. Check for assumption bleed, evaluation theater, and scope collapse before building
7. Apply the same extraction discipline to its own responses as to external sources
8. Surface this SOP doc when helpful for rehydration

---

## 19. Architectural Laws (Addendum — All Promoted)

1. **No genome without gate coupling.** Genome capsules not generating gate logic are museum exhibits that will drift.
2. **No language without decision.** Language/domain detection must always commit. "Unknown" is an architectural failure.
3. **No IR fallback conditional on AST success.** If the IR holds signal, the gate must receive it.
4. **No vector truth alone.** Vectors guide retrieval. Exact truth lives in the ledger.
5. **No centroid without residual.** Outliers spawn subfamilies; they are not compression targets.
6. **No SMEM promotion without retained contradiction.** The Contradiction Graph is not optional.
7. **No session without SBUF reset.** Working memory clears after consolidation.
8. **Temperature and distortion budget are one degree of freedom.** Treat them as such in calibration.
9. **No feature spine without QA spine.** They advance together or the build is untrustworthy.
10. **No architecture without governance twin.** Runtime and shadow-doc control co-evolve.
11. **No evaluation theater.** Structurally non-distinct conditions producing identical results are an implementation error, not data.
12. **No widening under unresolved failure modes.** Audit and resolve the current bottleneck before expanding scope.
13. **No substrate claim without empirical foothold.** Theory is theory until it survives contact with a benchmark.
14. **Separate to measure. Compose to run.** When strata are both present, isolate them for attribution, then compose them for production.

---

## 20. Final Short Form

This lab runs on:

> **PROBE → DERIVE → EMBODY → VERIFY → RECURSE**
> inside a persistent shadow-control layer,
> with zero-loss extraction for uploads (OIE + ELT + Systematic + DEFNLP),
> Loop+ for external research across primary science + discovery + buzzword + isomorph domains,
> explicit uncertainty and residual honesty,
> recursive replay after meaningful findings,
> no closure until variable neighborhoods have truly collapsed,
> evaluation discipline that names theater when it sees it,
> substrate claims requiring empirical foothold before advancing,
> workstream evidence kept separate by default,
> and the master loop (PROBE → DERIVE → EMBODY → VERIFY → RECURSE) as the non-negotiable control law.
>
> That is the lab.

# Extraction Manifest — SOP Package r3
_Generated: 2026-03-29_

## Corpus Sources

| # | Artifact | Type | Size | Role |
|---|---|---|---|---|
| C1 | PROJECT_WIDE_COMPREHENSIVE_SOP_2026-03-29au-r2.md | Control doc | ~30KB | Governing SOP (superseded by r3) |
| C2 | PROJECT_REHYDRATION_NOTE_2026-03-29au-r2.md | Control doc | ~1.8KB | Session entry point |
| C3 | EXTRACTION_MANIFEST.md | Manifest | ~800B | Prior corpus inventory |
| C4 | EXTRACTION_DOC.md | Extraction | ~18KB | OIE full extraction from prior session |
| C5 | EXTRACTION_MATRIX.md | Matrix | ~5.9KB | Standardized claim matrix |
| C6 | Tech_Concept_Evaluation.mht | Transcript | ~10.6MB | Full ChatGPT/GPT-5 session: TQ2 substrate research, weight thesis evaluation, MHT genealogy, RB-2R benchmark waves, project evaluation |

## Extraction Status

### C1–C5 (prior package)
- Phase A (ELT ingest): COMPLETE
- Phase B (OIE extraction): COMPLETE — see EXTRACTION_DOC.md
- Phase C (Standardized matrix): COMPLETE — see EXTRACTION_MATRIX.md
- Phase D (DEFNLP post-processing): COMPLETE
- Phase E (Control-layer integration): COMPLETE — integrated into r3 SOP

### C6 (Tech_Concept_Evaluation.mht) — NEW THIS PASS
- Phase A (ELT ingest): COMPLETE — full HTML extracted, ~974K chars of conversation text recovered
- Phase B (OIE extraction): COMPLETE — key entities, relations, claims extracted (see below)
- Phase C (Standardized matrix): PARTIAL — key claims captured in delta doc and SOP §16
- Phase D (DEFNLP post-processing): COMPLETE — evaluation theater, z_MAYBE, dual-head audit flagged
- Phase E (Control-layer integration): COMPLETE — new rules 11–14, new §6.2, §9.6, §12.3, §16 update

## Key Claims Extracted from C6

| ID | Claim | Evidence | Doctrine Effect | Status |
|---|---|---|---|---|
| C6-001 | TQ2 is canonical discrete geometric substrate; TQ1 is ancestral | Shadow docs explicit | Normative substrate confirmed | CLOSED |
| C6-002 | RB-2R_v3 hits 97.12% T1, 100% T2/T3, 53.50% T4 | Benchmark wave output | Best current integrated runtime | CLOSED |
| C6-003 | K2 shows route-structure accumulation across steps (gap +28.33 at step 6) | Latent probe data | K2 is the live fast lane | CLOSED |
| C6-004 | Dual-head test produced identical results to family-only — likely evaluation theater | Own evaluation doc | Dual-head result untrusted; audit required | OPEN — P0 |
| C6-005 | z_MAYBE actively hurts performance when ablated | Criticality map | Gate/drop z_MAYBE immediately | OPEN — P0 |
| C6-006 | Multi-path K2 collapses badly (K2_FAMILY 30.90% vs PER_STEP 52.08%) | Benchmark data | Central unresolved failure mode | OPEN — P0 |
| C6-007 | Project A (weight/distillation) has zero empirical foothold | Own evaluation doc | Score separately; Wave A1 required | OPEN |
| C6-008 | BASE-0 competes with or beats TQ2 runtime on text/sequence tasks | Benchmark data | Text domain not yet validated for TQ2 | OPEN |
| C6-009 | LATENT_FINAL_ONLY at 82.22% is underpowered and needs larger-N rerun | Extraction | Orphaned high-value finding | OPEN |
| C6-010 | K3 should stay meta/checkpoint only; revival only for multi-path regime | Evaluation | K3 doctrine confirmed | CLOSED |
| C6-011 | Manual corpus discipline is a process debt that will rot the project | Evaluation | Wave C1 (CIL ingest of corpus) queued | OPEN |
| C6-012 | PROBE→DERIVE→EMBODY→VERIFY→RECURSE confirmed as correct control law | Session conclusion | Instantiated in SOP §1.1 | CLOSED |
| C6-013 | Whole-plane, blockwise, hybrid strata: separate to measure, compose to run | Integrated runtime doctrine | New Law 14 | CLOSED |
| C6-014 | z80-LM is compression-doctrine ancestor; TQ2 is the geometric architecture | Genealogy extraction | Historical record; not normative spec | REFERENCE |
| C6-015 | The MHT thread is genealogy source, not normative spec | Evaluation | Status: source-thread genealogy | CLOSED |

## Orphaned High-Value Findings (Phase D — DEFNLP)

1. **Dual-head result requires structural audit before acceptance** — The extraction corpus itself identified this. Identical numbers across conditions is evaluation theater. Do not close until a structurally distinct reimplementation is run.

2. **z_MAYBE ablation result is the cheapest high-value intervention in the corpus** — Already flagged in extraction but not yet turned into a formal follow-up test. Gate/drop experiment should be Wave B1.3.

3. **LATENT_FINAL_ONLY is the strongest latent-kept result at 82.22%** — Still underpowered. Needs larger-N rerun before the finding can be promoted to doctrine.

4. **BASE-0 paradox in text/sequence** — As encoder improves (v1→recurrent v5), both BASE-0 and TQ2 runtime improve, but BASE-0 still competes. This is a real unresolved paradox. Transform-family ablation (Wave B2.1) is required before any text-domain claims.

5. **Project A has no empirical foothold** — The weight/distillation substrate is entirely theoretical until Wave A1 (toy distillation result) produces any output.

6. **Formal CIL ingest of the corpus has not happened** — The corpus is acting as a CIL case study but is not yet ingested. This should be Wave C1.

## Package File Index

| File | Role |
|---|---|
| UNIVERSAL_LM_RESEARCH_SOP_2026-03-29.md | Governing SOP (load first) |
| LOAD_FIRST_REHYDRATION_NOTE_2026-03-29.md | Session entry point |
| SOP_UPGRADE_DELTA_r2_to_r3.md | Change record: what changed and why |
| EXTRACTION_MANIFEST_r3.md | This file |

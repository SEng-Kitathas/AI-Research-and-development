# SOP Upgrade Delta: r2 → r3
_Date: 2026-03-29_
_Extraction source: Tech_Concept_Evaluation.mht (full read) + PROJECT_WIDE_SOP_PACKAGE r2_

---

## What Changed and Why

### 1. Universal Scope (New)
**r2** was Singularity Works / Forge / CIL specific.
**r3** is universal — applicable to any LM-assisted research or software project. Project-specific context is now isolated to §16 (clearly labeled, replaceable).

**Why:** The governing rules, master loop, extraction SOPs, evaluation discipline, and architectural laws are all transferable. The project-specific context belongs in its own section, not embedded throughout.

### 2. VERIFY Stage Made Explicit (Strengthened)
**r2** had PROBE → DERIVE → EMBODY → RECURSE.
**r3** adds VERIFY as an explicit named stage between EMBODY and RECURSE.

**Why:** The MHT conversation ends with the ChatGPT evaluation explicitly identifying the need for a verification brake. The loop without VERIFY allows mythology to accumulate. Embodiment without verification can feel like progress while producing nothing. The hard brake is the discipline.

### 3. Evaluation Theater Named and Governed (New)
**r2** did not address this failure mode explicitly.
**r3** adds Rule 11 (No evaluation theater), §6.2 (Evaluation Quality Standards including structural distinctness requirement), and §14.5 (benchmark SOP entry).

**Why:** The MHT evaluation corpus discovered that the dual-head readout test produced identical results to the family-only test. This is a real, named, repeatable failure mode: structurally non-distinct conditions reported as meaningful comparative data. It requires an explicit rule and audit protocol.

### 4. Substrate Claims vs. Empirical Foothold (New Rule)
**r2** did not explicitly require empirical grounding before advancing substrate claims.
**r3** adds Rule 13 (No substrate claims without empirical foothold) and §12.3.

**Why:** The MHT evaluation made the critical split between Project A (weight/distillation substrate — theory only) and Project B (reasoning/runtime substrate — real empirical signal). Conflating them leads to overclaiming. The rule forces explicit tracking of which workstream has empirical ground.

### 5. Workstream Separation Requirement (Strengthened)
**r2** had project separation rules (§16) but did not require separate scorecards.
**r3** adds Rule 14 (No project collapse into one undifferentiated mass) and §12.1 with the explicit scorecard separation requirement.

**Why:** The MHT evaluation corpus is clear: when two distinguishable projects share a corpus, their evidence must be scored separately. Evidence from one does not automatically carry to the other.

### 6. Process Automation Debt (New Rule)
**r2** did not address accumulating manual process debt.
**r3** adds Rule 15 (No process automation debt forever) and the CIL formal ingest recommendation in §16.2.

**Why:** The MHT evaluation explicitly identifies that the extraction discipline is conceptually strong but operationally manual. Manual discipline rots. The rule requires naming the debt and establishing a horizon for closing it.

### 7. Self-Evaluation Rule (New)
**r2** applied extraction discipline only to external sources.
**r3** adds §9.6 (Self-Evaluation Rule) and §18 minimum reply behavior item 7.

**Why:** The MHT evaluation found that the LM's responses needed to be evaluated using the same extraction standard applied to other sources. Overclaiming, underclaiming, and vague language in LM responses are failure modes as real as those in external sources.

### 8. TQ2/CIL Runtime State Updated (§16)
Updated to include:
- TQ2 runtime state (RB-2R_v3 as best integrated runtime)
- K2/K3 status (K2 = live fast lane, K3 = meta only)
- Project A / Project B scorecard split
- Full open seam list including dual-head audit, z_MAYBE, stepwise multi-path

### 9. New Isomorphisms Added (§15.4, §8.4)
Added from MHT extraction:
- TQ2 strata ↔ local+global invariant decomposition
- K2 accumulation ↔ episodic memory consolidation

### 10. New Architectural Laws (§19)
Added Laws 11–14:
- 11: No evaluation theater
- 12: No widening under unresolved failure modes
- 13: No substrate claim without empirical foothold
- 14: Separate to measure, compose to run

---

## What Was Preserved Verbatim

- All original 15 governing rules (r2 §3) — now §2 in r3, Laws 1–10
- Core vocabulary (all terms)
- Closure standard
- Session SOP (all four phases)
- Zero-loss upload SOP (all six phases)
- Research SOP Loop+ (all stages and source buckets)
- Reading/extraction discipline (all rules)
- Experiment SOP
- Benchmark/baseline SOP (extended, not replaced)
- Doctrine promotion SOP
- Compaction/context-loss recovery procedure
- All original architectural laws (§19 / Appendix A)
- Industry comparison map (Appendix B — now embedded in §16 project context)
- Project-specific context (§1.3 in r2 → §16 in r3, isolated and labeled)

---

## Files in This Package

1. `UNIVERSAL_LM_RESEARCH_SOP_2026-03-29.md` — the upgraded SOP (load this)
2. `LOAD_FIRST_REHYDRATION_NOTE_2026-03-29.md` — session entry point
3. `SOP_UPGRADE_DELTA_r2_to_r3.md` — this file
4. `EXTRACTION_MANIFEST_r3.md` — corpus inventory and extraction status

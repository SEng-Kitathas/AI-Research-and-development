# LOAD-FIRST REHYDRATION NOTE
_Version: 2026-03-29-r3_

Use **UNIVERSAL_LM_RESEARCH_SOP_2026-03-29.md** before any substantive project work.

If compaction happened or a new LM session is starting, load in this order:

1. **Universal SOP** (this package — includes master loop, governing rules, project-specific context §16)
2. Current doc set (trace matrix, crosswalk, addendum, maintenance note)
3. Latest next-steps / work queue doc
4. Latest SOP cycle update
5. Latest revisit ledger + supplement
6. Ontology / doctrine snapshot
7. Extraction docs relevant to current seam
8. Active-seam experiment reports

---

## Quick State Snapshot — Singularity Works / TQ2 / CIL (2026-03-29)

**Forge:** v1.11, Python, 35 capsules, 34 strategies, 38/38 hammer, 20/20 core, self-audit clean
**CIL:** ~140K LOC Rust, 19 crates, ForgeContext v4.0 wired (SBUF/EPMEM/SMEM/Contradiction)
**cil-forge:** 16 files, hecs ECS, compiles clean — stubs need fleshing out
**CIL Council:** v2.0 dialectic built (REASONER 35B + CODER 7B + GHOST 0.8B)
**Bridge:** forge_bridge.py + CLAUDE.md + lcc.bat + setup.bat — Windows-native
**TQ2 Runtime:** RB-2R_v3 is best integrated runtime; K2 is live fast lane; K3 is meta only

**Top priority open seams:**
- CIL-031: Workspace canonicalization — BLOCKING
- cil-council self-scan Law 1 fix — P1
- Dual-head code audit (evaluation theater suspected in prior result)
- Stepwise multi-path separability experiment
- z_MAYBE gate/drop experiment
- Toy distillation feasibility (Project A has zero empirical foothold)
- Fixed-point multi-hop propagation
- Interprocedural field sensitivity
- Warrant-carrying assurance graph

**Hard constraints that must survive every session:**
- Zero false greens (hard architectural invariant)
- Genome IS the generator (not a parallel catalog)
- Language-agnostic analysis (no "unknown", no implementation-language assumption bleed)
- IR fallback unconditional (not gated on AST success)
- Bug bounty mode stays local
- TQ2 strata: separate to measure, compose to run
- K3 is meta/checkpoint only — NOT live control

**Project scorecard split (must be maintained separately):**
- Project A (weight/distillation substrate): THEORY ONLY — no empirical foothold yet
- Project B (reasoning/runtime substrate): REAL SIGNAL — RB-2R_v3 confirmed, K2 confirmed

**Master loop:**
PROBE → DERIVE → EMBODY → VERIFY → RECURSE
(VERIFY is the hard brake — do not skip it)

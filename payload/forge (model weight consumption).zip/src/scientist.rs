//! # NEAL-FORGE Scientist
//!
//! Evaluates extracted organs to determine quality scores.
//! Implements the meritocratic principle: "Never replace a better weight with a lesser weight."
//!
//! ## Evaluation Strategy
//!
//! Different organ types require different evaluation methods:
//! - Attention: Context retention capability
//! - MLP: Reasoning/knowledge density
//! - Visual: Embedding alignment
//! - Audio: Reconstruction fidelity
//!
//! For now, we use heuristics based on:
//! 1. Entropy (information density)
//! 2. Source model reputation
//! 3. Organ type importance
//! 4. Layer position (middle layers often most valuable)

use neal_core::{NealResult, CapabilityDomain, Confidence};
use crate::surgeon::{Organ, OrganType};
use crate::manifest::HeistTarget;

/// Quality score for an organ [0.0, 1.0]
#[derive(Debug, Clone, Copy)]
pub struct QualityScore {
    /// Overall quality
    pub overall: f32,
    /// Entropy contribution
    pub entropy_score: f32,
    /// Source model reputation
    pub source_score: f32,
    /// Layer position score
    pub position_score: f32,
    /// Type importance score
    pub type_score: f32,
}

impl QualityScore {
    /// Create from components
    pub fn compute(entropy: f32, source: f32, position: f32, type_score: f32) -> Self {
        // Weighted combination
        let overall = entropy * 0.3 + source * 0.35 + position * 0.15 + type_score * 0.2;
        Self {
            overall: overall.clamp(0.0, 1.0),
            entropy_score: entropy,
            source_score: source,
            position_score: position,
            type_score,
        }
    }
}

/// The Scientist: evaluates organ quality
pub struct Scientist {
    /// Source model reputations by domain
    source_reputations: Vec<(&'static str, CapabilityDomain, f32)>,
}

impl Scientist {
    /// Create a new scientist
    pub fn new() -> Self {
        Self {
            // Based on SOTA benchmarks
            source_reputations: vec![
                // Reasoning champions
                ("DeepSeek-R1", CapabilityDomain::Reasoning, 0.99),
                ("DeepSeek", CapabilityDomain::Reasoning, 0.95),
                ("QwQ", CapabilityDomain::Reasoning, 0.92),
                
                // Coding champions
                ("Qwen2.5-Coder", CapabilityDomain::Code, 0.98),
                ("DeepSeek-Coder", CapabilityDomain::Code, 0.94),
                
                // Math champions
                ("QwQ", CapabilityDomain::Math, 0.97),
                ("DeepSeek-Math", CapabilityDomain::Math, 0.95),
                
                // General/Creative
                ("Llama-3.3", CapabilityDomain::Creative, 0.96),
                ("Llama-3.3", CapabilityDomain::Language, 0.95),
                
                // Vision
                ("Qwen2.5-VL", CapabilityDomain::Science, 0.97),
                
                // Audio
                ("Whisper", CapabilityDomain::Language, 0.96),
            ],
        }
    }
    
    /// Evaluate an organ's quality
    pub fn evaluate(&self, organ: &Organ) -> QualityScore {
        let entropy_score = self.score_entropy(organ);
        let source_score = self.score_source(organ);
        let position_score = self.score_position(organ);
        let type_score = self.score_type(organ);
        
        QualityScore::compute(entropy_score, source_score, position_score, type_score)
    }
    
    /// Compare two organs for the same semantic slot
    /// Returns true if `candidate` should replace `incumbent`
    pub fn is_upgrade(&self, candidate: &Organ, incumbent_score: f32) -> bool {
        let candidate_score = self.evaluate(candidate).overall;
        
        // Require significant improvement to replace (avoid thrashing)
        const UPGRADE_THRESHOLD: f32 = 0.05;
        candidate_score > incumbent_score + UPGRADE_THRESHOLD
    }
    
    /// Score based on entropy (information density)
    fn score_entropy(&self, organ: &Organ) -> f32 {
        // Entropy is already normalized to [0, 1]
        // Boost slightly for very high entropy
        let base = organ.entropy;
        if base > 0.9 {
            (base * 1.1).min(1.0)
        } else {
            base
        }
    }
    
    /// Score based on source model reputation
    fn score_source(&self, organ: &Organ) -> f32 {
        // Look up reputation
        for (name_pattern, domain, reputation) in &self.source_reputations {
            if organ.source_model.contains(name_pattern) && organ.domain == *domain {
                return *reputation;
            }
        }
        
        // Check domain match without specific model
        for (name_pattern, domain, reputation) in &self.source_reputations {
            if organ.source_model.contains(name_pattern) {
                // Slight penalty for domain mismatch
                return reputation * 0.8;
            }
        }
        
        // Unknown source - baseline
        0.5
    }
    
    /// Score based on layer position
    fn score_position(&self, organ: &Organ) -> f32 {
        match organ.layer_index {
            Some(layer) => {
                // Middle layers are often most valuable for abstraction
                // Early layers: raw features
                // Late layers: task-specific
                // Middle layers: generalizable concepts
                
                // Assume typical model has ~40 layers
                let relative_pos = (layer as f32) / 40.0;
                
                // Bell curve centered at 0.5
                let distance_from_middle = (relative_pos - 0.5).abs();
                1.0 - (distance_from_middle * 1.5).min(0.4)
            }
            None => 0.7, // No layer info - assume moderate value
        }
    }
    
    /// Score based on organ type
    fn score_type(&self, organ: &Organ) -> f32 {
        match organ.organ_type {
            // Core reasoning/attention
            OrganType::Attention => 0.95,
            OrganType::Gate => 0.95, // MoE gates are very valuable
            
            // Knowledge storage
            OrganType::MlpUp | OrganType::MlpDown => 0.85,
            
            // Output shaping
            OrganType::AttentionOutput => 0.80,
            
            // Specialized encoders
            OrganType::VisualEncoder => 0.90,
            OrganType::AudioEncoder => 0.90,
            OrganType::PatchEmbed => 0.85,
            
            // Utility
            OrganType::Norm => 0.60,
            OrganType::Embedding => 0.70,
            
            OrganType::Unknown => 0.50,
        }
    }
}

impl Default for Scientist {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    
    fn mock_organ(source: &str, domain: CapabilityDomain, entropy: f32, layer: Option<u32>, organ_type: OrganType) -> Organ {
        Organ {
            id: format!("{}::test", source),
            source_model: source.to_string(),
            tensor_name: "test.tensor".to_string(),
            domain,
            layer_index: layer,
            organ_type,
            data: vec![],
            dtype: crate::surgeon::DataType::F16,
            shape: vec![1024, 1024],
            size_bytes: 0,
            entropy,
            hash: [0; 32],
        }
    }
    
    #[test]
    fn test_deepseek_reasoning_scores_high() {
        let scientist = Scientist::new();
        let organ = mock_organ(
            "DeepSeek-R1",
            CapabilityDomain::Reasoning,
            0.9,
            Some(20),
            OrganType::Gate,
        );
        
        let score = scientist.evaluate(&organ);
        assert!(score.overall > 0.9, "DeepSeek reasoning should score > 0.9, got {}", score.overall);
    }
    
    #[test]
    fn test_upgrade_threshold() {
        let scientist = Scientist::new();
        
        // Same model, same domain - should not upgrade with tiny improvement
        let incumbent_score = 0.85;
        let organ = mock_organ(
            "DeepSeek-R1",
            CapabilityDomain::Reasoning,
            0.86, // Slightly higher entropy
            Some(20),
            OrganType::Gate,
        );
        
        // The threshold prevents minor fluctuations from causing thrashing
        // (depends on exact scoring, so this is more of a sanity check)
    }
}

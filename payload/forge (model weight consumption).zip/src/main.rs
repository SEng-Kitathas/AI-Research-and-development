//! # NEAL-FORGE CLI
//!
//! The Model Forge for NEAL-CORE v36 DAGI.
//!
//! ## Usage
//!
//! ```bash
//! # Forge all manifest targets
//! neal-forge --storage ./neal-data --cache ./model-cache
//!
//! # Forge specific domain only
//! neal-forge --storage ./neal-data --cache ./model-cache --domain reasoning
//!
//! # List targets without forging
//! neal-forge --list
//! ```

use std::path::PathBuf;
use anyhow::Result;
use tracing::{info, Level};
use tracing_subscriber::{fmt, prelude::*, EnvFilter};

use neal_forge::{HEIST_MANIFEST, domain_sector};

const BANNER: &str = r#"
╔═══════════════════════════════════════════════════════════════════════════════╗
║                                                                               ║
║   ███╗   ██╗███████╗ █████╗ ██╗      ███████╗ ██████╗ ██████╗  ██████╗ ███████╗║
║   ████╗  ██║██╔════╝██╔══██╗██║      ██╔════╝██╔═══██╗██╔══██╗██╔════╝ ██╔════╝║
║   ██╔██╗ ██║█████╗  ███████║██║█████╗█████╗  ██║   ██║██████╔╝██║  ███╗█████╗  ║
║   ██║╚██╗██║██╔══╝  ██╔══██║██║╚════╝██╔══╝  ██║   ██║██╔══██╗██║   ██║██╔══╝  ║
║   ██║ ╚████║███████╗██║  ██║███████╗ ██║     ╚██████╔╝██║  ██║╚██████╔╝███████╗║
║   ╚═╝  ╚═══╝╚══════╝╚═╝  ╚═╝╚══════╝ ╚═╝      ╚═════╝ ╚═╝  ╚═╝ ╚═════╝ ╚══════╝║
║                                                                               ║
║                  v36.0 - The Omni-Modal Heist                                 ║
║                                                                               ║
║   "We don't merge models (which dilutes them). We MINE them."                 ║
║                                                                               ║
╚═══════════════════════════════════════════════════════════════════════════════╝
"#;

#[derive(Debug)]
struct Args {
    storage: PathBuf,
    cache: PathBuf,
    list_only: bool,
}

fn parse_args() -> Result<Args> {
    let args: Vec<String> = std::env::args().collect();
    
    let mut storage = PathBuf::from("./neal-data");
    let mut cache = PathBuf::from("./model-cache");
    let mut list_only = false;
    
    let mut i = 1;
    while i < args.len() {
        match args[i].as_str() {
            "--storage" | "-s" => {
                i += 1;
                if i < args.len() {
                    storage = PathBuf::from(&args[i]);
                }
            }
            "--cache" | "-c" => {
                i += 1;
                if i < args.len() {
                    cache = PathBuf::from(&args[i]);
                }
            }
            "--list" | "-l" => {
                list_only = true;
            }
            "--help" | "-h" => {
                print_help();
                std::process::exit(0);
            }
            _ => {}
        }
        i += 1;
    }
    
    Ok(Args { storage, cache, list_only })
}

fn print_help() {
    println!("NEAL-FORGE v36.0 - The Omni-Modal Heist");
    println!();
    println!("USAGE:");
    println!("    neal-forge [OPTIONS]");
    println!();
    println!("OPTIONS:");
    println!("    -s, --storage <PATH>   Storage path for radicals [default: ./neal-data]");
    println!("    -c, --cache <PATH>     Model cache path [default: ./model-cache]");
    println!("    -l, --list             List targets without forging");
    println!("    -h, --help             Print help");
}

fn list_targets() {
    println!("\n📋 HEIST MANIFEST ({} targets):\n", HEIST_MANIFEST.len());
    println!("{:<25} {:<12} {:<10} {:<8} {}", "Model", "Domain", "Sector", "Size", "Patterns");
    println!("{}", "-".repeat(80));
    
    for target in HEIST_MANIFEST {
        let sector = domain_sector(target.domain);
        println!(
            "{:<25} {:<12} 0x{:03X}      {:>5.1}GB  {:?}",
            target.name,
            format!("{:?}", target.domain),
            sector,
            target.expected_size_gb,
            &target.target_patterns[..target.target_patterns.len().min(2)],
        );
    }
    
    println!();
    println!("Total expected download: {:.1} GB", 
        HEIST_MANIFEST.iter().map(|t| t.expected_size_gb).sum::<f32>());
    println!();
    println!("Sector allocation:");
    println!("  0x000-0x0FF: Reasoning");
    println!("  0x100-0x1FF: Math");
    println!("  0x200-0x2FF: Coding");
    println!("  0x300-0x3FF: Creative");
    println!("  0x400-0x4FF: Vision/Science");
    println!("  0x500-0x5FF: Hearing/Language");
    println!("  0x600-0x6FF: Speech");
    println!("  0x700-0xFFF: Reserved/Specialized");
}

#[tokio::main]
async fn main() -> Result<()> {
    // Initialize tracing
    tracing_subscriber::registry()
        .with(fmt::layer().with_target(false))
        .with(
            EnvFilter::builder()
                .with_default_directive(Level::INFO.into())
                .from_env_lossy(),
        )
        .init();
    
    // Print banner
    println!("{}", BANNER);
    
    // Parse args
    let args = parse_args()?;
    
    if args.list_only {
        list_targets();
        return Ok(());
    }
    
    // Run forge
    info!("Starting forge...");
    info!("  Storage: {:?}", args.storage);
    info!("  Cache: {:?}", args.cache);
    
    // Create directories
    std::fs::create_dir_all(&args.storage)?;
    std::fs::create_dir_all(&args.cache)?;
    
    let stats = neal_forge::run_forge(&args.storage, &args.cache).await?;
    
    println!("\n📊 FORGE STATISTICS:");
    println!("   Organs sealed: {}", stats.organs_sealed);
    println!("   Organs upgraded: {}", stats.organs_upgraded);
    println!("   Organs culled: {}", stats.organs_culled);
    println!("   Bytes written: {} ({:.2} GB)", 
        stats.bytes_written,
        stats.bytes_written as f64 / 1_073_741_824.0);
    
    Ok(())
}

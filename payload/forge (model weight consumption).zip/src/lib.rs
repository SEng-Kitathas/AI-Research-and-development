//! # NEAL-FORGE
//!
//! The Model Forge for NEAL-CORE v36 DAGI.
//!
//! ## Purpose
//!
//! NEAL-FORGE extracts the best functional blocks ("organs") from SOTA models
//! and fuses them into a unified Radical Storage substrate.
//!
//! ## Architecture
//!
//! ```text
//! ┌─────────────────────────────────────────────────────────────────────────┐
//! │                         NEAL-FORGE                                       │
//! ├─────────────────────────────────────────────────────────────────────────┤
//! │                                                                          │
//! │  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐              │
//! │  │   MANIFEST   │───▶│   SURGEON    │───▶│  SCIENTIST   │              │
//! │  │ (Target List)│    │ (Extraction) │    │ (Evaluation) │              │
//! │  └──────────────┘    └──────────────┘    └──────┬───────┘              │
//! │                                                  │                       │
//! │                                                  ▼                       │
//! │                                          ┌──────────────┐               │
//! │                                          │   ENGINEER   │               │
//! │                                          │  (Mapping)   │               │
//! │                                          └──────┬───────┘               │
//! │                                                  │                       │
//! │                                                  ▼                       │
//! │                                          ┌──────────────┐               │
//! │                                          │  ARTIFICER   │               │
//! │                                          │  (Storage)   │               │
//! │                                          └──────────────┘               │
//! │                                                  │                       │
//! │                                                  ▼                       │
//! │                                          ┌──────────────┐               │
//! │                                          │   RADICALS   │               │
//! │                                          │ /galaxy/...  │               │
//! │                                          └──────────────┘               │
//! │                                                                          │
//! └─────────────────────────────────────────────────────────────────────────┘
//! ```
//!
//! ## The Heist
//!
//! We target SOTA models for specific capabilities:
//! - **DeepSeek-R1**: Reasoning (MoE gates, deep logic layers)
//! - **Qwen2.5-Coder**: Code generation (all attention heads)
//! - **Llama-3.3**: Creative writing (middle layer attention)
//! - **QwQ**: Mathematics (calculation layers)
//! - **Qwen2.5-VL**: Vision (visual encoder)
//! - **Whisper**: Audio (encoder convolutions)
//!
//! ## Meritocratic Principle
//!
//! > "Never replace a better weight with a lesser weight."
//!
//! When two models provide organs for the same semantic slot, we keep
//! the one with higher quality score.

#![deny(missing_docs)]

pub mod manifest;
pub mod surgeon;
pub mod scientist;
pub mod engineer;
pub mod artificer;

pub use manifest::{HeistTarget, HEIST_MANIFEST, domain_sector, calculate_radical_address};
pub use surgeon::{Surgeon, Organ, OrganType, DataType};
pub use scientist::{Scientist, QualityScore};
pub use engineer::Engineer;
pub use artificer::{Artificer, ForgeStats};

/// Run the full forge cycle on all manifest targets
pub async fn run_forge(
    storage_path: &std::path::Path,
    model_cache: &std::path::Path,
) -> neal_core::NealResult<ForgeStats> {
    use tracing::{info, warn, error, debug};
    
    info!("🔥 IGNITING NEAL-FORGE v36.0");
    info!("   Storage: {:?}", storage_path);
    info!("   Cache: {:?}", model_cache);
    info!("   Targets: {} models", HEIST_MANIFEST.len());
    
    // Initialize components
    let surgeon = Surgeon::new();
    let scientist = Scientist::new();
    let engineer = Engineer::new();
    let mut artificer = Artificer::new(storage_path)?;
    
    // Process targets in priority order
    for target in manifest::targets_by_priority() {
        info!("🔨 FORGING: {} (domain: {:?}, priority: {})", 
            target.name, target.domain, target.priority);
        
        // Construct model path (handle both flat and nested layouts)
        let model_name = target.hf_id.replace('/', "_");
        let model_path = model_cache.join(&model_name);
        
        // Look for safetensors file
        let safetensors_path = if model_path.join("model.safetensors").exists() {
            model_path.join("model.safetensors")
        } else if model_path.join("model-00001-of-00001.safetensors").exists() {
            model_path.join("model-00001-of-00001.safetensors")
        } else if model_path.with_extension("safetensors").exists() {
            model_path.with_extension("safetensors")
        } else {
            warn!("   ⚠️  Model not found at {:?}, skipping", model_path);
            warn!("      Expected: model.safetensors or similar");
            continue;
        };
        
        info!("   📂 Loading from {:?}", safetensors_path);
        
        // 1. SURGERY: Extract organs
        let organs = match surgeon.extract(target, &safetensors_path) {
            Ok(o) => o,
            Err(e) => {
                error!("   ❌ Surgery failed: {}", e);
                continue;
            }
        };
        
        info!("   🫀 Extracted {} organs", organs.len());
        
        for organ in organs {
            // 2. SCIENCE: Evaluate quality
            let score = scientist.evaluate(&organ);
            
            // 3. ENGINEERING: Calculate address
            let address = engineer.locate(&organ);
            
            // 4. ARTIFICE: Meritocratic write
            if artificer.is_upgrade(address, score) {
                match artificer.seal(address, organ.clone(), score).await {
                    Ok(()) => {
                        let current = artificer.current_score(address).unwrap_or(0.0);
                        info!(
                            "   ✨ SEALED: {} -> {:016x} (score: {:.3})",
                            organ.id, address.0, score.overall
                        );
                    }
                    Err(e) => {
                        error!("   ❌ Seal failed for {}: {}", organ.id, e);
                    }
                }
            } else {
                let current = artificer.current_score(address).unwrap_or(0.0);
                debug!(
                    "   🗑️  CULLED: {} (score {:.3} ≤ current {:.3})",
                    organ.id, score.overall, current
                );
                artificer.record_cull();
            }
        }
    }
    
    // Flush registry
    artificer.flush()?;
    
    // Print summary
    info!("\n{}", artificer.summary());
    
    let stats = artificer.stats().clone();
    info!("✅ FORGE COMPLETE");
    info!("   Sealed: {} organs", stats.organs_sealed);
    info!("   Upgraded: {} organs", stats.organs_upgraded);
    info!("   Culled: {} organs", stats.organs_culled);
    info!("   Written: {:.2} GB", stats.bytes_written as f64 / 1_073_741_824.0);
    
    Ok(stats)
}

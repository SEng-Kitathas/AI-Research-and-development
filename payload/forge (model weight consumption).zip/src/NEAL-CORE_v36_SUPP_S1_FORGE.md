# NEAL-CORE v36.0 SUPPLEMENTARY
# Document S1: OMNI-MODAL FORGE

**Status:** Supplementary Documentation (derived from Rust implementation)
**Purpose:** Documents the neal-forge crate for strip-mining SOTA models

---

## OVERVIEW

The Omni-Modal Forge implements the "Heist" - extracting functional weight blocks
from SOTA models and fusing them into a unified Radical Storage substrate.

**Philosophy:** "We don't merge models (which dilutes them). We MINE them."

---

## TARGET MANIFEST (12 Models)

| Target | Domain | Priority | Size |
|--------|--------|----------|------|
| DeepSeek-R1 | Reasoning | 100 | 120 GB |
| Qwen2.5-Coder-32B | Code | 95 | 65 GB |
| QwQ-32B | Math | 90 | 65 GB |
| Llama-3.3-70B | Creative | 85 | 140 GB |
| Qwen2.5-VL-72B | Vision | 80 | 145 GB |
| Whisper-Large-v3 | Hearing | 75 | 3 GB |
| Fish-Speech-1.5 | Speech | 65 | 2 GB |
| OpenVLA-7B | Action | 60 | 14 GB |
| OpenFold3 | Biology | 55 | 20 GB |
| Chronos-T5-Large | Time | 50 | 1.5 GB |
| Phi-3.5-mini | General | 40 | 7.6 GB |

---

## PIPELINE

```
MANIFEST → SURGEON → SCIENTIST → ENGINEER → ARTIFICER
(Targets)  (Extract)  (Evaluate)  (Address)   (Seal)
```

1. **Manifest:** Defines targets and tensor patterns
2. **Surgeon:** Extracts organs via safetensors
3. **Scientist:** Computes QualityScore (entropy, source, position, type)
4. **Engineer:** Maps to 48-bit Hilbert address
5. **Artificer:** Enforces meritocratic write

---

## SECTOR ALLOCATION

```
0x000-0x0FF: Reasoning (256 radicals)
0x100-0x1FF: Math (256 radicals)
0x200-0x2FF: Coding (256 radicals)
0x300-0x3FF: Creative (256 radicals)
0x400-0x4FF: Science (256 radicals)
0x500-0x5FF: Language (256 radicals)
...
```

---

## MERITOCRATIC INVARIANT

> **"Never replace a better weight with a lesser weight."**

Enforced by:
```rust
fn is_upgrade(&self, address: WeightRegionId, score: QualityScore) -> bool {
    match self.ledger.get(&address) {
        Some(current) => score.overall > current + 0.02, // 2% threshold
        None => true, // Empty slot
    }
}
```

---

## RUST CRATE: neal-forge

**Location:** `crates/neal-forge/`
**Lines:** ~1,717

| Module | Lines | Purpose |
|--------|-------|---------|
| manifest.rs | 307 | Target definitions |
| surgeon.rs | 393 | Weight extraction |
| scientist.rs | 251 | Quality scoring |
| engineer.rs | 131 | Address mapping |
| artificer.rs | 288 | Storage writer |
| lib.rs | 173 | Orchestration |
| main.rs | 174 | CLI |

---

**END OF SUPPLEMENTARY S1**

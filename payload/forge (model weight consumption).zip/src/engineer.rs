//! # NEAL-FORGE Engineer
//!
//! Maps functional organs to physical Radical Addresses.
//!
//! ## Address Structure
//!
//! A WeightRegionId is a 48-bit Hilbert index:
//! ```text
//! ┌────────────────┬────────────────────────────────────────┐
//! │  Radical (12)  │           Sequence (36)                │
//! │  Domain sector │   Content-addressed slot within sector │
//! └────────────────┴────────────────────────────────────────┘
//! ```
//!
//! This ensures:
//! - Organs from the same domain cluster together (spatial locality)
//! - Same content always lands at same address (deterministic)
//! - Collisions trigger meritocratic comparison

use neal_core::WeightRegionId;
use crate::surgeon::Organ;
use crate::manifest::calculate_radical_address;

/// The Engineer: maps semantic function to physical address
pub struct Engineer;

impl Engineer {
    /// Create a new engineer
    pub fn new() -> Self { 
        Self 
    }

    /// Calculate the immutable destination for this organ.
    ///
    /// Two organs with the same domain and functional ID will always
    /// get the same address, enabling meritocratic comparison.
    pub fn locate(&self, organ: &Organ) -> WeightRegionId {
        // 1. Calculate Radical (12-bit) based on Domain + functional ID
        //    This places all "Reasoning" organs in sector 0x000-0x0FF, etc.
        let radical = calculate_radical_address(organ.domain, &organ.id);
        
        // 2. Calculate Sequence (36-bit) from content hash
        //    This determines the specific slot within the sector.
        //    Using content hash means identical weights always collide.
        let sequence = self.hash_to_sequence(&organ.hash);

        // 3. Combine into WeightRegionId (48-bit Hilbert Index)
        //    Format: Radical (12 bits) | Sequence (36 bits)
        let hilbert_index = ((radical as u64) << 36) | sequence;
        
        WeightRegionId::from_hilbert(hilbert_index)
    }
    
    /// Convert first 8 bytes of hash to 36-bit sequence
    fn hash_to_sequence(&self, hash: &[u8; 32]) -> u64 {
        let mut seq_bytes = [0u8; 8];
        seq_bytes.copy_from_slice(&hash[0..8]);
        let raw = u64::from_le_bytes(seq_bytes);
        
        // Mask to 36 bits (max value: 68,719,476,735)
        raw & 0x000F_FFFF_FFFF
    }
    
    /// Calculate address for a functional tag (without full organ)
    /// Useful for lookups and pre-allocation
    pub fn locate_by_tag(&self, domain: neal_core::CapabilityDomain, functional_id: &str) -> WeightRegionId {
        let radical = calculate_radical_address(domain, functional_id);
        
        // For tag-based lookup, use hash of the ID as sequence
        let hash = blake3::hash(functional_id.as_bytes());
        let mut seq_bytes = [0u8; 8];
        seq_bytes.copy_from_slice(&hash.as_bytes()[0..8]);
        let sequence = u64::from_le_bytes(seq_bytes) & 0x000F_FFFF_FFFF;
        
        let hilbert_index = ((radical as u64) << 36) | sequence;
        WeightRegionId::from_hilbert(hilbert_index)
    }
}

impl Default for Engineer {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use neal_core::CapabilityDomain;
    
    #[test]
    fn test_deterministic_addressing() {
        let engineer = Engineer::new();
        
        // Same domain + ID should always get same radical
        let addr1 = engineer.locate_by_tag(CapabilityDomain::Reasoning, "deepseek.layer.12.gate");
        let addr2 = engineer.locate_by_tag(CapabilityDomain::Reasoning, "deepseek.layer.12.gate");
        
        assert_eq!(addr1.0, addr2.0, "Same input should produce same address");
    }
    
    #[test]
    fn test_domain_separation() {
        let engineer = Engineer::new();
        
        let reasoning = engineer.locate_by_tag(CapabilityDomain::Reasoning, "test");
        let coding = engineer.locate_by_tag(CapabilityDomain::Code, "test");
        
        // Extract radicals (top 12 bits)
        let reasoning_radical = reasoning.radical();
        let coding_radical = coding.radical();
        
        // Should be in different sectors
        assert_ne!(
            reasoning_radical / 256, 
            coding_radical / 256, 
            "Different domains should be in different sectors"
        );
    }
    
    #[test]
    fn test_sequence_range() {
        let engineer = Engineer::new();
        let hash: [u8; 32] = [0xFF; 32]; // Max hash
        
        let sequence = engineer.hash_to_sequence(&hash);
        
        // Should be masked to 36 bits
        assert!(sequence <= 0x000F_FFFF_FFFF, "Sequence should be <= 36 bits");
    }
}

//! # NEAL-FORGE Surgeon
//!
//! Dissects model files and extracts functional weight blocks ("organs").
//!
//! ## Architecture Handling
//!
//! Different model families have different tensor naming conventions:
//! - Llama/Qwen: `model.layers.{N}.self_attn.{q,k,v}_proj`
//! - Whisper: `model.encoder.layers.{N}.self_attn`
//! - DeepSeek MoE: `model.layers.{N}.mlp.experts.{E}`
//!
//! The Surgeon normalizes these into a common `Organ` format.

use std::path::Path;
use std::collections::HashMap;
use memmap2::Mmap;
use safetensors::SafeTensors;
use tracing::{info, warn, debug};

use neal_core::{NealResult, NealError, CapabilityDomain, WeightRegionId};
use crate::manifest::HeistTarget;

/// A standardized functional unit extracted from a model
#[derive(Debug, Clone)]
pub struct Organ {
    /// Unique identifier: "{model}::{tensor_name}"
    pub id: String,
    
    /// Source model name
    pub source_model: String,
    
    /// Original tensor name in the model
    pub tensor_name: String,
    
    /// Capability domain
    pub domain: CapabilityDomain,
    
    /// Layer index (if applicable)
    pub layer_index: Option<u32>,
    
    /// Organ type (attention, mlp, etc.)
    pub organ_type: OrganType,
    
    /// Raw weight data (f16 or bf16 typically)
    pub data: Vec<u8>,
    
    /// Data type
    pub dtype: DataType,
    
    /// Shape [dim0, dim1, ...]
    pub shape: Vec<usize>,
    
    /// Size in bytes
    pub size_bytes: usize,
    
    /// Entropy score (information density heuristic)
    pub entropy: f32,
    
    /// Content hash for deduplication
    pub hash: [u8; 32],
}

/// Type of functional unit
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum OrganType {
    /// Query/Key/Value projection
    Attention,
    /// Output projection
    AttentionOutput,
    /// Gate projection (MoE or standard)
    Gate,
    /// Up projection in MLP
    MlpUp,
    /// Down projection in MLP
    MlpDown,
    /// Layer normalization
    Norm,
    /// Embedding
    Embedding,
    /// Visual encoder block
    VisualEncoder,
    /// Audio encoder block
    AudioEncoder,
    /// Patch embedding
    PatchEmbed,
    /// Unknown/other
    Unknown,
}

/// Data type of weights
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum DataType {
    F32,
    F16,
    BF16,
    I8,
    I4,
    Unknown,
}

impl DataType {
    fn from_safetensors(dtype: safetensors::Dtype) -> Self {
        match dtype {
            safetensors::Dtype::F32 => DataType::F32,
            safetensors::Dtype::F16 => DataType::F16,
            safetensors::Dtype::BF16 => DataType::BF16,
            safetensors::Dtype::I8 => DataType::I8,
            _ => DataType::Unknown,
        }
    }
    
    /// Bytes per element
    pub fn element_size(&self) -> usize {
        match self {
            DataType::F32 => 4,
            DataType::F16 | DataType::BF16 => 2,
            DataType::I8 => 1,
            DataType::I4 => 1, // Packed
            DataType::Unknown => 1,
        }
    }
}

/// The Surgeon: extracts organs from model files
pub struct Surgeon {
    /// Minimum entropy to keep (filters dead weights)
    min_entropy: f32,
}

impl Surgeon {
    /// Create a new surgeon
    pub fn new() -> Self {
        Self {
            min_entropy: 0.1, // Minimum information density
        }
    }
    
    /// Perform surgery on a target model
    pub fn extract(&self, target: &HeistTarget, path: &Path) -> NealResult<Vec<Organ>> {
        info!("😷 INCISION: Opening {} at {:?}", target.name, path);
        
        // Memory-map the file
        let file = std::fs::File::open(path).map_err(|e| NealError::Io {
            operation: "open".into(),
            path: path.to_path_buf(),
            source: e.to_string().into(),
        })?;
        
        let mmap = unsafe { Mmap::map(&file) }.map_err(|e| NealError::Io {
            operation: "mmap".into(),
            path: path.to_path_buf(),
            source: e.to_string().into(),
        })?;
        
        // Parse safetensors
        let tensors = SafeTensors::deserialize(&mmap).map_err(|e| NealError::Serialization {
            reason: format!("safetensors parse: {}", e).into(),
        })?;
        
        let mut organs = Vec::new();
        let mut total_extracted = 0usize;
        let mut total_skipped = 0usize;
        
        for name in tensors.names() {
            // Check if this tensor matches our target patterns
            if !self.matches_patterns(name, target.target_patterns) {
                continue;
            }
            
            // Check layer range
            if let Some((start, end)) = target.layer_range {
                if let Some(layer) = self.parse_layer_index(name) {
                    if layer < start || layer > end {
                        debug!("Skipping {} (layer {} outside range [{}, {}])", name, layer, start, end);
                        continue;
                    }
                }
            }
            
            // Extract the tensor
            let tensor = tensors.tensor(name).map_err(|e| NealError::Serialization {
                reason: format!("tensor '{}': {}", name, e).into(),
            })?;
            
            let data = tensor.data().to_vec();
            let entropy = self.calculate_entropy(&data);
            
            // Filter dead weights
            if entropy < self.min_entropy {
                debug!("Skipping {} (entropy {:.3} below threshold)", name, entropy);
                total_skipped += 1;
                continue;
            }
            
            let hash = *blake3::hash(&data).as_bytes();
            let shape: Vec<usize> = tensor.shape().to_vec();
            let dtype = DataType::from_safetensors(tensor.dtype());
            
            let organ = Organ {
                id: format!("{}::{}", target.name, name),
                source_model: target.name.to_string(),
                tensor_name: name.to_string(),
                domain: target.domain,
                layer_index: self.parse_layer_index(name),
                organ_type: self.classify_organ(name),
                size_bytes: data.len(),
                data,
                dtype,
                shape,
                entropy,
                hash,
            };
            
            total_extracted += 1;
            organs.push(organ);
        }
        
        info!(
            "   🫀 EXTRACTED {} organs from {} ({} skipped)",
            total_extracted, target.name, total_skipped
        );
        
        Ok(organs)
    }
    
    /// Check if tensor name matches any target pattern
    fn matches_patterns(&self, name: &str, patterns: &[&str]) -> bool {
        for pattern in patterns {
            // Simple glob matching (* = any)
            let parts: Vec<&str> = pattern.split('*').collect();
            
            if parts.len() == 1 {
                // No wildcard - exact contains match
                if name.contains(pattern) {
                    return true;
                }
            } else {
                // Has wildcards - check prefix/suffix
                let mut pos = 0;
                let mut matched = true;
                
                for (i, part) in parts.iter().enumerate() {
                    if part.is_empty() {
                        continue;
                    }
                    
                    if let Some(found) = name[pos..].find(part) {
                        if i == 0 && found != 0 {
                            // First part must be prefix
                            matched = false;
                            break;
                        }
                        pos += found + part.len();
                    } else {
                        matched = false;
                        break;
                    }
                }
                
                if matched {
                    return true;
                }
            }
        }
        false
    }
    
    /// Parse layer index from tensor name
    fn parse_layer_index(&self, name: &str) -> Option<u32> {
        // Handle various formats:
        // - "layers.12.attn"
        // - "model.layers.12.self_attn"
        // - "encoder.blocks.12"
        
        for part in name.split('.') {
            if let Ok(n) = part.parse::<u32>() {
                // Sanity check - layer indices are typically < 200
                if n < 200 {
                    return Some(n);
                }
            }
        }
        None
    }
    
    /// Classify organ type from tensor name
    fn classify_organ(&self, name: &str) -> OrganType {
        let name_lower = name.to_lowercase();
        
        if name_lower.contains("q_proj") || name_lower.contains("k_proj") || name_lower.contains("v_proj") {
            OrganType::Attention
        } else if name_lower.contains("o_proj") || name_lower.contains("out_proj") {
            OrganType::AttentionOutput
        } else if name_lower.contains("gate") || name_lower.contains("moe_gate") {
            OrganType::Gate
        } else if name_lower.contains("up_proj") || name_lower.contains("fc1") {
            OrganType::MlpUp
        } else if name_lower.contains("down_proj") || name_lower.contains("fc2") {
            OrganType::MlpDown
        } else if name_lower.contains("norm") || name_lower.contains("ln_") {
            OrganType::Norm
        } else if name_lower.contains("embed") && !name_lower.contains("patch") {
            OrganType::Embedding
        } else if name_lower.contains("patch_embed") {
            OrganType::PatchEmbed
        } else if name_lower.contains("visual") || name_lower.contains("vision") {
            OrganType::VisualEncoder
        } else if name_lower.contains("encoder") && (name_lower.contains("conv") || name_lower.contains("audio")) {
            OrganType::AudioEncoder
        } else {
            OrganType::Unknown
        }
    }
    
    /// Calculate Shannon entropy of weight data
    /// Higher entropy = more information = more valuable
    fn calculate_entropy(&self, data: &[u8]) -> f32 {
        if data.is_empty() {
            return 0.0;
        }
        
        // Count byte frequencies
        let mut counts = [0u64; 256];
        for &b in data {
            counts[b as usize] += 1;
        }
        
        // Calculate entropy
        let len = data.len() as f64;
        let mut entropy = 0.0f64;
        
        for &count in &counts {
            if count > 0 {
                let p = count as f64 / len;
                entropy -= p * p.log2();
            }
        }
        
        // Normalize to [0, 1] range (max entropy for bytes is 8 bits)
        (entropy / 8.0) as f32
    }
}

impl Default for Surgeon {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_pattern_matching() {
        let surgeon = Surgeon::new();
        
        assert!(surgeon.matches_patterns("layers.12.self_attn.q_proj", &["self_attn"]));
        assert!(surgeon.matches_patterns("layers.12.self_attn.q_proj", &["layers.*.self_attn"]));
        assert!(!surgeon.matches_patterns("layers.12.mlp", &["self_attn"]));
    }
    
    #[test]
    fn test_layer_parsing() {
        let surgeon = Surgeon::new();
        
        assert_eq!(surgeon.parse_layer_index("layers.12.attn"), Some(12));
        assert_eq!(surgeon.parse_layer_index("model.layers.0.mlp"), Some(0));
        assert_eq!(surgeon.parse_layer_index("encoder.blocks.24"), Some(24));
    }
    
    #[test]
    fn test_organ_classification() {
        let surgeon = Surgeon::new();
        
        assert_eq!(surgeon.classify_organ("layers.0.self_attn.q_proj"), OrganType::Attention);
        assert_eq!(surgeon.classify_organ("layers.0.mlp.gate_proj"), OrganType::Gate);
        assert_eq!(surgeon.classify_organ("visual.blocks.0"), OrganType::VisualEncoder);
    }
    
    #[test]
    fn test_entropy_calculation() {
        let surgeon = Surgeon::new();
        
        // Zero entropy for constant data
        let zeros = vec![0u8; 1000];
        assert!(surgeon.calculate_entropy(&zeros) < 0.01);
        
        // Higher entropy for random-ish data
        let varied: Vec<u8> = (0..=255).cycle().take(1000).collect();
        assert!(surgeon.calculate_entropy(&varied) > 0.9);
    }
}

//! # NEAL-FORGE Manifest
//!
//! The target list for the Omni-Modal Heist.
//! Each target maps to a CapabilityDomain from neal-core.
//!
//! ## Philosophy
//!
//! We don't merge models (which dilutes them). We **mine** them.
//! Extract the "Reasoning Neurons" from DeepSeek, the "Coding Neurons"
//! from Qwen, and place them into the same Radical Storage.
//!
//! ## Sector Allocation
//!
//! The 4096 radicals (12-bit address space) are partitioned by domain:
//! - 0x000-0x0FF: Reasoning (256 radicals)
//! - 0x100-0x1FF: Math (256 radicals)  
//! - 0x200-0x2FF: Coding (256 radicals)
//! - 0x300-0x3FF: Creative (256 radicals)
//! - 0x400-0x4FF: Vision (256 radicals)
//! - 0x500-0x5FF: Hearing (256 radicals)
//! - 0x600-0x6FF: Speech (256 radicals)
//! - 0x700-0x7FF: Science (256 radicals)
//! - 0x800-0x8FF: Action/Robotics (256 radicals)
//! - 0x900-0x9FF: Time/Prediction (256 radicals)
//! - 0xA00-0xBFF: General/Factual (512 radicals)
//! - 0xC00-0xFFF: Reserved (1024 radicals)

use neal_core::CapabilityDomain;
use std::collections::HashMap;

/// A target model to strip-mine
#[derive(Debug, Clone)]
pub struct HeistTarget {
    /// Human-readable name
    pub name: &'static str,
    
    /// Primary capability domain
    pub domain: CapabilityDomain,
    
    /// HuggingFace model ID (org/model)
    pub hf_id: &'static str,
    
    /// Specific tensor name patterns to extract (regex-style)
    pub target_patterns: &'static [&'static str],
    
    /// Layer range to focus on (start, end) - None means all
    pub layer_range: Option<(u32, u32)>,
    
    /// Expected size in GB (for planning)
    pub expected_size_gb: f32,
    
    /// Priority (higher = extract first)
    pub priority: u8,
}

/// The master manifest of all targets
pub const HEIST_MANIFEST: &[HeistTarget] = &[
    // ═══════════════════════════════════════════════════════════════════════
    // THE CORTEX: Logic & Language
    // ═══════════════════════════════════════════════════════════════════════
    
    HeistTarget {
        name: "DeepSeek-R1",
        domain: CapabilityDomain::Reasoning,
        hf_id: "deepseek-ai/DeepSeek-R1",
        // The MoE gating mechanisms are the decision-makers
        target_patterns: &[
            "layers.*.moe_gate",
            "layers.*.mlp.gate",
            "layers.*.self_attn",
        ],
        layer_range: Some((10, 40)), // Deep reasoning layers
        expected_size_gb: 120.0,
        priority: 100, // Highest - reasoning is core
    },
    
    HeistTarget {
        name: "Qwen2.5-Coder-32B",
        domain: CapabilityDomain::Code,
        hf_id: "Qwen/Qwen2.5-Coder-32B-Instruct",
        // All attention for syntax understanding
        target_patterns: &[
            "layers.*.self_attn",
            "layers.*.mlp",
        ],
        layer_range: None, // All layers - coding needs full context
        expected_size_gb: 65.0,
        priority: 95,
    },
    
    HeistTarget {
        name: "Llama-3.3-70B",
        domain: CapabilityDomain::Creative,
        hf_id: "meta-llama/Llama-3.3-70B-Instruct",
        // Self-attention for nuanced context
        target_patterns: &[
            "layers.*.self_attn",
        ],
        layer_range: Some((20, 60)), // Middle layers for abstraction
        expected_size_gb: 140.0,
        priority: 85,
    },
    
    HeistTarget {
        name: "QwQ-32B",
        domain: CapabilityDomain::Math,
        hf_id: "Qwen/QwQ-32B-Preview",
        // The calculation layers
        target_patterns: &[
            "layers.*.mlp",
        ],
        layer_range: Some((10, 24)), // Core math processing
        expected_size_gb: 65.0,
        priority: 90,
    },
    
    // ═══════════════════════════════════════════════════════════════════════
    // THE SENSES: Perception
    // ═══════════════════════════════════════════════════════════════════════
    
    HeistTarget {
        name: "Qwen2.5-VL-72B",
        domain: CapabilityDomain::Science, // Vision is a "science" sense
        hf_id: "Qwen/Qwen2.5-VL-72B-Instruct",
        // The visual encoder (the eye)
        target_patterns: &[
            "visual.blocks",
            "visual.patch_embed",
            "visual.merger",
        ],
        layer_range: None,
        expected_size_gb: 145.0,
        priority: 80,
    },
    
    HeistTarget {
        name: "Whisper-Large-v3-Turbo",
        domain: CapabilityDomain::Language, // Audio→text is language
        hf_id: "openai/whisper-large-v3-turbo",
        // The audio encoder (the ear)
        target_patterns: &[
            "model.encoder.conv1",
            "model.encoder.conv2",
            "model.encoder.layers",
        ],
        layer_range: None,
        expected_size_gb: 3.0, // Whisper is relatively small
        priority: 75,
    },
    
    // ═══════════════════════════════════════════════════════════════════════
    // THE BODY: Action & Physics
    // ═══════════════════════════════════════════════════════════════════════
    
    HeistTarget {
        name: "OpenVLA-7B",
        domain: CapabilityDomain::Science, // Robotics is applied physics
        hf_id: "openvla/openvla-7b",
        // The action prediction head (the hands)
        target_patterns: &[
            "action_head",
            "model.vision_tower",
        ],
        layer_range: None,
        expected_size_gb: 14.0,
        priority: 60,
    },
    
    HeistTarget {
        name: "OpenFold3",
        domain: CapabilityDomain::Science, // Biology is science
        hf_id: "openfold/openfold3-trunk",
        // The geometry engine (protein folding physics)
        target_patterns: &[
            "evoformer",
            "structure_module",
        ],
        layer_range: None,
        expected_size_gb: 20.0,
        priority: 55,
    },
    
    HeistTarget {
        name: "Chronos-T5-Large",
        domain: CapabilityDomain::Science, // Time-series prediction is science
        hf_id: "amazon/chronos-t5-large",
        // The cerebellum (temporal pattern matching)
        target_patterns: &[
            "encoder.block",
            "shared",
        ],
        layer_range: None,
        expected_size_gb: 1.5,
        priority: 50,
    },
    
    // ═══════════════════════════════════════════════════════════════════════
    // THE VOICE: Speech Synthesis
    // ═══════════════════════════════════════════════════════════════════════
    
    HeistTarget {
        name: "Fish-Speech-1.5",
        domain: CapabilityDomain::Language, // TTS is language production
        hf_id: "fishaudio/fish-speech-1.5",
        // The vocal cords (speech generation)
        target_patterns: &[
            "model.decoder",
            "model.generator",
        ],
        layer_range: None,
        expected_size_gb: 2.0,
        priority: 65,
    },
    
    // ═══════════════════════════════════════════════════════════════════════
    // EFFICIENCY FALLBACK
    // ═══════════════════════════════════════════════════════════════════════
    
    HeistTarget {
        name: "Phi-3.5-mini",
        domain: CapabilityDomain::General, // Efficiency model for edge cases
        hf_id: "microsoft/Phi-3.5-mini-instruct",
        // Efficient knowledge compression
        target_patterns: &[
            "layers.*.mlp",
        ],
        layer_range: None,
        expected_size_gb: 7.6,
        priority: 40, // Lower priority - fallback only
    },
];

/// Radical sector assignments by domain
pub fn domain_sector(domain: CapabilityDomain) -> u16 {
    match domain {
        CapabilityDomain::Reasoning => 0x000,
        CapabilityDomain::Math => 0x100,
        CapabilityDomain::Code => 0x200,
        CapabilityDomain::Creative => 0x300,
        CapabilityDomain::Science => 0x400, // Also Vision
        CapabilityDomain::Language => 0x500, // Also Hearing
        CapabilityDomain::Factual => 0xA00,
        // High-stakes domains get their own sectors
        CapabilityDomain::Medical => 0x700,
        CapabilityDomain::Legal => 0x780,
        CapabilityDomain::Financial => 0x800,
        CapabilityDomain::Safety => 0x880,
        CapabilityDomain::General => 0xB00,
    }
}

/// Calculate radical address for an organ
pub fn calculate_radical_address(domain: CapabilityDomain, organ_id: &str) -> u16 {
    let base = domain_sector(domain);
    
    // Hash the organ ID to get offset within sector
    let hash = blake3::hash(organ_id.as_bytes());
    let offset = (hash.as_bytes()[0] as u16) % 256;
    
    base + offset
}

/// Get all targets for a specific domain
pub fn targets_for_domain(domain: CapabilityDomain) -> Vec<&'static HeistTarget> {
    HEIST_MANIFEST
        .iter()
        .filter(|t| t.domain == domain)
        .collect()
}

/// Get targets sorted by priority
pub fn targets_by_priority() -> Vec<&'static HeistTarget> {
    let mut targets: Vec<_> = HEIST_MANIFEST.iter().collect();
    targets.sort_by(|a, b| b.priority.cmp(&a.priority));
    targets
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_sector_allocation() {
        // Verify sectors don't overlap
        let sectors: Vec<u16> = vec![
            domain_sector(CapabilityDomain::Reasoning),
            domain_sector(CapabilityDomain::Math),
            domain_sector(CapabilityDomain::Code),
        ];
        
        for i in 0..sectors.len() {
            for j in (i+1)..sectors.len() {
                assert!(
                    (sectors[i] as i32 - sectors[j] as i32).abs() >= 256,
                    "Sectors {} and {} overlap", sectors[i], sectors[j]
                );
            }
        }
    }
    
    #[test]
    fn test_address_determinism() {
        let addr1 = calculate_radical_address(CapabilityDomain::Reasoning, "deepseek.layer.12.attn");
        let addr2 = calculate_radical_address(CapabilityDomain::Reasoning, "deepseek.layer.12.attn");
        assert_eq!(addr1, addr2, "Same organ should always get same address");
    }
}

//! # NEAL-FORGE Artificer
//!
//! Seals extracted organs into Radical Storage.
//! Implements meritocratic write: only upgrades, never downgrades.
//!
//! ## The Gatekeeper
//!
//! The Artificer enforces the cardinal rule:
//! > "Never replace a better weight with a lesser weight."
//!
//! When two organs collide at the same address, only the higher-quality
//! one survives.

use std::path::{Path, PathBuf};
use std::collections::HashMap;
use std::sync::Arc;
use std::fs;
use tracing::{info, warn, debug};

use neal_core::{NealResult, NealError, WeightRegionId, CapabilityDomain};
use neal_storage::RadicalStorage;
use crate::surgeon::Organ;
use crate::scientist::QualityScore;

/// Metadata for a stored organ
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct OrganMetadata {
    /// Original organ ID
    pub id: String,
    /// Source model
    pub source_model: String,
    /// Quality score
    pub quality_score: f32,
    /// Domain
    pub domain: String,
    /// Size in bytes
    pub size_bytes: usize,
    /// Content hash (hex)
    pub hash: String,
    /// Timestamp (unix seconds)
    pub sealed_at: u64,
    /// Full address
    pub address: u64,
}

/// Registry of stored organs (persisted as JSON)
#[derive(Debug, Default, serde::Serialize, serde::Deserialize)]
pub struct OrganRegistry {
    /// Address -> Metadata
    pub organs: HashMap<u64, OrganMetadata>,
    /// Total bytes stored
    pub total_bytes: usize,
    /// Total organs sealed
    pub total_organs: usize,
}

/// Forge statistics
#[derive(Debug, Default, Clone)]
pub struct ForgeStats {
    /// Organs successfully sealed
    pub organs_sealed: u64,
    /// Organs that upgraded existing
    pub organs_upgraded: u64,
    /// Organs culled (inferior)
    pub organs_culled: u64,
    /// Total bytes written
    pub bytes_written: u64,
}

/// The Artificer: writes organs to storage with meritocratic enforcement
pub struct Artificer {
    /// Radical storage backend
    storage: Arc<RadicalStorage>,
    /// In-memory ledger (address -> score)
    ledger: HashMap<u64, f32>,
    /// Full registry (persisted)
    registry: OrganRegistry,
    /// Registry file path
    registry_path: PathBuf,
    /// Statistics
    stats: ForgeStats,
}

impl Artificer {
    /// Create or open storage at path
    pub fn new(path: impl Into<PathBuf>) -> NealResult<Self> {
        let storage_path = path.into();
        
        // Initialize RadicalStorage
        let storage = Arc::new(RadicalStorage::new(&storage_path)?);
        
        // Load or create registry
        let registry_path = storage_path.join("registry.json");
        let registry = if registry_path.exists() {
            let data = fs::read_to_string(&registry_path).map_err(|e| NealError::Io {
                operation: "read".into(),
                path: registry_path.clone(),
                source: e.to_string().into(),
            })?;
            serde_json::from_str(&data).unwrap_or_default()
        } else {
            OrganRegistry::default()
        };
        
        // Build ledger from registry
        let ledger: HashMap<u64, f32> = registry
            .organs
            .iter()
            .map(|(&addr, meta)| (addr, meta.quality_score))
            .collect();
        
        info!(
            "Artificer initialized at {:?} ({} organs in registry)", 
            storage_path, 
            registry.organs.len()
        );
        
        Ok(Self {
            storage,
            ledger,
            registry,
            registry_path,
            stats: ForgeStats::default(),
        })
    }
    
    /// Check if an organ would be an upgrade at its address
    pub fn is_upgrade(&self, address: WeightRegionId, score: QualityScore) -> bool {
        let key = address.0;
        
        match self.ledger.get(&key) {
            Some(&current_best) => {
                // Meritocratic Check: Must be strictly better (with threshold)
                const UPGRADE_THRESHOLD: f32 = 0.02;
                score.overall > current_best + UPGRADE_THRESHOLD
            }
            None => true, // Empty slot - always accept
        }
    }
    
    /// Get current quality score at an address
    pub fn current_score(&self, address: WeightRegionId) -> Option<f32> {
        self.ledger.get(&address.0).copied()
    }
    
    /// Seal an organ to storage
    pub async fn seal(
        &mut self, 
        address: WeightRegionId, 
        organ: Organ, 
        score: QualityScore
    ) -> NealResult<()> {
        let key = address.0;
        
        // Check if this is an upgrade
        let is_upgrade = self.ledger.contains_key(&key);
        
        // Write raw weight data to RadicalStorage
        self.storage.write_blob(address, &organ.data).await?;
        
        // Update ledger
        self.ledger.insert(key, score.overall);
        
        // Update registry
        let metadata = OrganMetadata {
            id: organ.id.clone(),
            source_model: organ.source_model.clone(),
            quality_score: score.overall,
            domain: format!("{:?}", organ.domain),
            size_bytes: organ.size_bytes,
            hash: hex::encode(&organ.hash),
            sealed_at: std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_secs(),
            address: key,
        };
        
        self.registry.organs.insert(key, metadata);
        self.registry.total_bytes += organ.size_bytes;
        self.registry.total_organs += 1;
        
        // Update stats
        self.stats.organs_sealed += 1;
        self.stats.bytes_written += organ.size_bytes as u64;
        if is_upgrade {
            self.stats.organs_upgraded += 1;
        }
        
        debug!(
            "Sealed {} -> {:016x} (score: {:.3}, size: {} bytes{})",
            organ.id, 
            key, 
            score.overall, 
            organ.size_bytes,
            if is_upgrade { " UPGRADE" } else { "" }
        );
        
        Ok(())
    }
    
    /// Record a culled organ (not stored because inferior)
    pub fn record_cull(&mut self) {
        self.stats.organs_culled += 1;
    }
    
    /// Save registry to disk
    pub fn flush(&self) -> NealResult<()> {
        let data = serde_json::to_string_pretty(&self.registry).map_err(|e| NealError::Serialization {
            reason: e.to_string().into(),
        })?;
        
        fs::write(&self.registry_path, data).map_err(|e| NealError::Io {
            operation: "write".into(),
            path: self.registry_path.clone(),
            source: e.to_string().into(),
        })?;
        
        info!(
            "Registry flushed ({} organs, {} bytes total)", 
            self.registry.organs.len(), 
            self.registry.total_bytes
        );
        
        Ok(())
    }
    
    /// Get statistics
    pub fn stats(&self) -> &ForgeStats {
        &self.stats
    }
    
    /// Get registry summary by domain
    pub fn summary(&self) -> String {
        let mut by_domain: HashMap<String, (usize, usize)> = HashMap::new();
        
        for meta in self.registry.organs.values() {
            let entry = by_domain.entry(meta.domain.clone()).or_insert((0, 0));
            entry.0 += 1;
            entry.1 += meta.size_bytes;
        }
        
        let mut summary = format!(
            "Registry: {} organs, {:.2} GB\n",
            self.registry.organs.len(),
            self.registry.total_bytes as f64 / 1_073_741_824.0
        );
        
        let mut domains: Vec<_> = by_domain.iter().collect();
        domains.sort_by(|a, b| b.1.0.cmp(&a.1.0));
        
        for (domain, (count, bytes)) in domains {
            summary.push_str(&format!(
                "  {:12} {:>5} organs  {:>8.2} MB\n", 
                domain, 
                count,
                *bytes as f64 / 1_048_576.0
            ));
        }
        
        summary
    }
}

impl Drop for Artificer {
    fn drop(&mut self) {
        if let Err(e) = self.flush() {
            warn!("Failed to flush registry on drop: {}", e);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use tempfile::tempdir;
    
    #[test]
    fn test_empty_slot_accepts() {
        let dir = tempdir().unwrap();
        let artificer = Artificer::new(dir.path()).unwrap();
        
        let addr = WeightRegionId::from_hilbert(0x100_0000_0000);
        let score = crate::scientist::QualityScore::compute(0.8, 0.8, 0.8, 0.8);
        
        assert!(artificer.is_upgrade(addr, score));
    }
}

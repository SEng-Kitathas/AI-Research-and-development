# Universal Lab SOP Package — Lab-Grade Chimera Edition
_Version: 2026-03-29_

## What This Is

A best-practices Chimera SOP designed for lab-grade LM-assisted research and software projects. Not a checklist. The operating system.

**Synthesized from:**
- NIH ELN Standards (2024) — immutable audit trail, raw data preservation
- OECD/FDA GLP (21 CFR Part 58) — deviation tracking, null result recording, QA audit loops
- ISO/IEC 17025 — traceability chains, method validation, workstream separation
- PRISMA 2020 + Open Science Pre-Registration — confirmatory/exploratory split, HARKing prevention, kill criteria
- MLOps Reproducibility Standards — version everything, deterministic pipelines, data lineage
- Singularity Works / Forge / CIL / TQ2 research lineage — PROBE→DERIVE→EMBODY→VERIFY→RECURSE, shadow-control layer, evaluation theater governance, zero-loss extraction

## Files

| File | Role | Load order |
|---|---|---|
| `LOAD_FIRST_REHYDRATION_NOTE.md` | Session entry point | 1st |
| `UNIVERSAL_LAB_SOP_2026-03-29.md` | Governing SOP | 2nd |
| `EXPERIMENT_PREREGISTRATION_LOG.md` | Pre-registration log (blank) | Fill in at project start |
| `DEVIATION_LOG.md` | Deviation log (blank) | Fill in as deviations occur |
| `EVALUATION_LOG.md` | Per-workstream scorecard (blank) | Fill in at project start |
| `EXPERIMENT_SPEC_AND_REPORT_TEMPLATES.md` | Diagnostic experiment templates | Copy per experiment |
| `SHADOW_DOC_TEMPLATES.md` | All other shadow doc templates | Copy and fill in |
| `CHIMERA_LINEAGE_MAP.md` | What came from where and why | Reference |

## How to Start a Project

1. Upload this archive
2. Read the rehydration note
3. Read the SOP
4. Copy templates from `SHADOW_DOC_TEMPLATES.md` into project-specific files
5. Create working versions of: Current State, Next Steps, Trace Matrix, Doctrine Snapshot, Revisit Ledger
6. Create blank: Pre-Registration Log, Deviation Log, Evaluation Log (with workstream scorecards)
7. Declare incumbent baseline per workstream
8. Declare first experiment as exploratory or confirmatory
9. Begin work

## Resume Command

> "Read the archive in load order. Rehydrate the project state from the shadow docs. Re-state incumbent baseline vs. open seams per workstream. Check the Deviation Log for anything unresolved. Check the Evaluation Log for theater flags. Then continue from the Next Steps file."

## Key Additions Over Prior Versions (ax/ay/r3)

| What's New | Why It Matters |
|---|---|
| Confirmatory / Exploratory pre-declaration (§2) | Prevents HARKing — the most common way research self-deceives |
| Experiment Pre-Registration Log | Locks analysis plan before data is observed |
| Deviation Log | Deviations recorded before analysis, not adopted silently |
| Evaluation Log with per-workstream scorecards | Separate evidence lines; null results required |
| Kill criteria as mandatory field | A confirmatory experiment without a kill criterion is theater |
| Structural distinctness check as mandatory field | Catches evaluation theater before it enters the record |
| "Nearby variables still open" as mandatory field | Forces honest accounting of what each experiment does NOT close |
| Bidirectional recursive replay fields | Positive AND null results both trigger specific replay obligations |
| Null result recording requirement (R-19) | Null results are data; suppression is a process violation |
| Process debt tracking in Maintenance Note | Names the debt so it can be closed |
| Chimera Lineage Map | Full audit trail of what came from where |

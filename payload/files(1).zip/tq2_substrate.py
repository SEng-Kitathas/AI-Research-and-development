"""
TQ2 substrate implementation — reference semantics
Based on TQ2_OBJECT_GRAMMAR_2026-03-29b and TQ2_INTEGRATED_INFERENCE_ARCHITECTURE_2026-03-29c
"""
import numpy as np
from sklearn.neural_network import MLPClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import f1_score
from collections import defaultdict
import json, csv, warnings
warnings.filterwarnings('ignore')

# ── Transforms ──────────────────────────────────────────────────────────────

WHOLE_PLANE_TRANSFORMS = [
    lambda x: x.copy(),
    lambda x: np.rot90(x, 1),
    lambda x: np.rot90(x, 2),
    lambda x: np.rot90(x, 3),
    lambda x: np.fliplr(x),
    lambda x: np.flipud(x),
    lambda x: x.T.copy(),
    lambda x: np.rot90(x.T, 2),
]

BLOCK_TRANSFORMS = [
    lambda b: b.copy(),
    lambda b: np.roll(b, -1),
    lambda b: np.roll(b,  1),
]

# ── Similarity ───────────────────────────────────────────────────────────────

def sim_plane(a, b):
    return int(np.sum(a == b))

def sim_block(a, b):
    return int(np.sum(a == b))

# ── Scoring surfaces ─────────────────────────────────────────────────────────

def score_wholeplane(plane, proto):
    return max(sim_plane(t(plane), proto) for t in WHOLE_PLANE_TRANSFORMS)

def score_blockwise(plane, proto):
    total = 0
    for i in range(3):
        total += max(sim_block(bt(plane[i]), proto[i]) for bt in BLOCK_TRANSFORMS)
    return total

# ── Task generators ──────────────────────────────────────────────────────────

def rng_plane(rng):
    return rng.choice([-1, 0, 1], size=(3, 3)).astype(np.int8)

def apply_rand_whole(plane, rng):
    return WHOLE_PLANE_TRANSFORMS[rng.integers(len(WHOLE_PLANE_TRANSFORMS))](plane).astype(np.int8)

def apply_rand_block(plane, rng):
    out = plane.copy()
    for i in range(3):
        t = BLOCK_TRANSFORMS[rng.integers(len(BLOCK_TRANSFORMS))]
        out[i] = t(plane[i])
    return out

def add_noise(plane, rng, rate=0.05):
    out = plane.copy()
    for idx in range(9):
        if rng.random() < rate:
            out.flat[idx] = rng.choice([-1, 0, 1])
    return out

def generate_T1(seed, n_classes=4, n_per_class=20):
    """Whole-plane motif invariance: label = which prototype family under global transforms"""
    rng = np.random.default_rng(seed)
    protos = [rng_plane(rng) for _ in range(n_classes)]
    X, y = [], []
    for cls, proto in enumerate(protos):
        for _ in range(n_per_class):
            s = add_noise(apply_rand_whole(proto, rng), rng, 0.05)
            X.append(s.flatten()); y.append(cls)
    return np.array(X, dtype=np.int8), np.array(y), protos

def generate_T2(seed, n_classes=4, n_per_class=20):
    """Block composition invariance: label = which prototype family under block-local shifts"""
    rng = np.random.default_rng(seed)
    protos = [rng_plane(rng) for _ in range(n_classes)]
    X, y = [], []
    for cls, proto in enumerate(protos):
        for _ in range(n_per_class):
            s = add_noise(apply_rand_block(proto, rng), rng, 0.05)
            X.append(s.flatten()); y.append(cls)
    return np.array(X, dtype=np.int8), np.array(y), protos

def generate_T3(seed, n_per_class=27):
    """Majority-sign sanity: label = sign bucket of sum"""
    rng = np.random.default_rng(seed)
    # 3 classes: negative (<-2), neutral (-2..2), positive (>2)
    thresholds = [(-9, -3), (-2, 2), (3, 9)]
    X, y = [], []
    for cls, (lo, hi) in enumerate(thresholds):
        count = 0
        while count < n_per_class:
            p = rng_plane(rng)
            s = int(np.sum(p))
            if lo <= s <= hi:
                X.append(p.flatten()); y.append(cls); count += 1
    return np.array(X, dtype=np.int8), np.array(y), None

def generate_T4(seed, n_classes=4, n_per_class=20):
    """Mixed global+local: label depends on BOTH global symmetry family AND block composition"""
    rng = np.random.default_rng(seed)
    g_protos = [rng_plane(rng) for _ in range(2)]
    l_protos = [rng_plane(rng) for _ in range(2)]
    protos = []
    for g in g_protos:
        for l in l_protos:
            mixed = np.vstack([g[:2], l[2:]]).astype(np.int8)
            protos.append(mixed)
    X, y = [], []
    for cls, proto in enumerate(protos):
        for _ in range(n_per_class):
            if rng.random() < 0.5:
                s = apply_rand_whole(proto, rng)
            else:
                s = apply_rand_block(proto, rng)
            s = add_noise(s, rng, 0.05)
            X.append(s.flatten()); y.append(cls)
    return np.array(X, dtype=np.int8), np.array(y), protos

# ── Models ───────────────────────────────────────────────────────────────────

class BASE0:
    def fit(self, X, y, **kw):
        self.protos = {}
        for c in np.unique(y):
            m = X[y == c].mean(axis=0)
            self.protos[c] = np.sign(m).reshape(3,3).astype(np.int8)
        return self

    def predict(self, X):
        return np.array([max(self.protos, key=lambda c: sim_plane(x.reshape(3,3), self.protos[c])) for x in X])

class RB2A:
    def fit(self, X, y, **kw):
        self.protos = {}
        for c in np.unique(y):
            m = X[y == c].mean(axis=0)
            self.protos[c] = np.sign(m).reshape(3,3).astype(np.int8)
        return self

    def predict(self, X):
        return np.array([max(self.protos, key=lambda c: score_wholeplane(x.reshape(3,3), self.protos[c])) for x in X])

class RB2B:
    def fit(self, X, y, **kw):
        self.protos = {}
        for c in np.unique(y):
            m = X[y == c].mean(axis=0)
            self.protos[c] = np.sign(m).reshape(3,3).astype(np.int8)
        return self

    def predict(self, X):
        return np.array([max(self.protos, key=lambda c: score_blockwise(x.reshape(3,3), self.protos[c])) for x in X])

class RB2R_v3:
    def fit(self, X, y, task_type='mixed', **kw):
        self.task_type = task_type
        self.protos = {}
        for c in np.unique(y):
            m = X[y == c].mean(axis=0)
            self.protos[c] = np.sign(m).reshape(3,3).astype(np.int8)
        return self

    def predict(self, X):
        out = []
        for x in X:
            p = x.reshape(3,3)
            tt = self.task_type
            if tt == 'polarity':
                s = int(np.sum(p))
                label = 1 if s > 2 else (0 if s >= -2 else -1)
                # Map to class by polarity affinity
                best, best_s = None, -999
                for c, proto in self.protos.items():
                    ps = int(np.sum(proto))
                    pl = 1 if ps > 2 else (0 if ps >= -2 else -1)
                    if pl == label:
                        sc = sim_plane(p, proto)
                        if sc > best_s:
                            best_s = sc; best = c
                if best is None:
                    best = max(self.protos, key=lambda c: sim_plane(p, self.protos[c]))
                out.append(best)
            elif tt == 'global':
                out.append(max(self.protos, key=lambda c: score_wholeplane(p, self.protos[c])))
            elif tt == 'local':
                out.append(max(self.protos, key=lambda c: score_blockwise(p, self.protos[c])))
            else:  # mixed
                ws = {c: score_wholeplane(p, pr) for c, pr in self.protos.items()}
                bs = {c: score_blockwise(p, pr) for c, pr in self.protos.items()}
                wmax = max(ws.values()) or 1; bmax = max(bs.values()) or 1
                fused = {c: 0.5*(ws[c]/wmax) + 0.5*(bs[c]/bmax) for c in self.protos}
                out.append(max(fused, key=fused.get))
        return np.array(out)

class MLPBase:
    def __init__(self, hidden=(64,64), max_iter=500):
        self.hidden = hidden; self.max_iter = max_iter
        self.scaler = StandardScaler()
        self.clf = MLPClassifier(hidden_layer_sizes=hidden, activation='relu',
                                 max_iter=max_iter, random_state=42, early_stopping=True,
                                 validation_fraction=0.15)
    def fit(self, X, y, **kw):
        Xs = self.scaler.fit_transform(X.astype(float))
        self.clf.fit(Xs, y); return self
    def predict(self, X):
        return self.clf.predict(self.scaler.transform(X.astype(float)))

class LogRegBase:
    def __init__(self):
        self.scaler = StandardScaler()
        self.clf = LogisticRegression(max_iter=1000, random_state=42, C=1.0)
    def fit(self, X, y, **kw):
        Xs = self.scaler.fit_transform(X.astype(float))
        self.clf.fit(Xs, y); return self
    def predict(self, X):
        return self.clf.predict(self.scaler.transform(X.astype(float)))

# ── Evaluation ────────────────────────────────────────────────────────────────

def macro_f1(y_true, y_pred):
    classes = np.unique(np.concatenate([y_true, y_pred]))
    f1s = []
    for c in classes:
        tp = np.sum((y_pred==c)&(y_true==c))
        fp = np.sum((y_pred==c)&(y_true!=c))
        fn = np.sum((y_pred!=c)&(y_true==c))
        p = tp/(tp+fp) if (tp+fp)>0 else 0
        r = tp/(tp+fn) if (tp+fn)>0 else 0
        f1s.append(2*p*r/(p+r) if (p+r)>0 else 0)
    return float(np.mean(f1s))

def evaluate(model, X_test, y_test):
    preds = model.predict(X_test)
    acc = float(np.mean(preds == y_test))
    f1 = macro_f1(y_test, preds)
    return acc, f1

print("TQ2 substrate loaded OK")

# ── Prototype-bound model variants (use true prototypes, not estimated from mean) ──

class BASE0_bound:
    """BASE-0 with access to true bound prototypes (as per radical binding spec)"""
    def fit(self, X, y, protos=None, **kw):
        if protos is not None:
            self.protos = {i: np.array(p) for i, p in enumerate(protos)}
        else:
            self.protos = {}
            for c in np.unique(y):
                m = X[y==c].mean(axis=0)
                self.protos[c] = np.sign(m).reshape(3,3).astype(np.int8)
        return self
    def predict(self, X):
        return np.array([max(self.protos, key=lambda c: sim_plane(x.reshape(3,3), self.protos[c])) for x in X])

class RB2A_bound:
    def fit(self, X, y, protos=None, **kw):
        if protos is not None:
            self.protos = {i: np.array(p) for i, p in enumerate(protos)}
        else:
            self.protos = {}
            for c in np.unique(y):
                m = X[y==c].mean(axis=0)
                self.protos[c] = np.sign(m).reshape(3,3).astype(np.int8)
        return self
    def predict(self, X):
        return np.array([max(self.protos, key=lambda c: score_wholeplane(x.reshape(3,3), self.protos[c])) for x in X])

class RB2B_bound:
    def fit(self, X, y, protos=None, **kw):
        if protos is not None:
            self.protos = {i: np.array(p) for i, p in enumerate(protos)}
        else:
            self.protos = {}
            for c in np.unique(y):
                m = X[y==c].mean(axis=0)
                self.protos[c] = np.sign(m).reshape(3,3).astype(np.int8)
        return self
    def predict(self, X):
        return np.array([max(self.protos, key=lambda c: score_blockwise(x.reshape(3,3), self.protos[c])) for x in X])

class RB2R_v3_bound:
    def fit(self, X, y, protos=None, task_type='mixed', **kw):
        self.task_type = task_type
        if protos is not None:
            self.protos = {i: np.array(p) for i, p in enumerate(protos)}
        else:
            self.protos = {}
            for c in np.unique(y):
                m = X[y==c].mean(axis=0)
                self.protos[c] = np.sign(m).reshape(3,3).astype(np.int8)
        return self
    def predict(self, X):
        out = []
        for x in X:
            p = x.reshape(3,3)
            tt = self.task_type
            if tt == 'polarity':
                s = int(np.sum(p))
                label = 1 if s > 2 else (0 if s >= -2 else -1)
                best, best_s = None, -999
                for c, proto in self.protos.items():
                    ps = int(np.sum(proto))
                    pl = 1 if ps > 2 else (0 if ps >= -2 else -1)
                    if pl == label:
                        sc = sim_plane(p, proto)
                        if sc > best_s:
                            best_s = sc; best = c
                if best is None:
                    best = max(self.protos, key=lambda c: sim_plane(p, self.protos[c]))
                out.append(best)
            elif tt == 'global':
                out.append(max(self.protos, key=lambda c: score_wholeplane(p, self.protos[c])))
            elif tt == 'local':
                out.append(max(self.protos, key=lambda c: score_blockwise(p, self.protos[c])))
            else:
                ws = {c: score_wholeplane(p, pr) for c, pr in self.protos.items()}
                bs = {c: score_blockwise(p, pr) for c, pr in self.protos.items()}
                wmax = max(ws.values()) or 1; bmax = max(bs.values()) or 1
                fused = {c: 0.5*(ws[c]/wmax) + 0.5*(bs[c]/bmax) for c in self.protos}
                out.append(max(fused, key=fused.get))
        return np.array(out)

print("Prototype-bound variants loaded")

# TQ2 / CIL Revisit Ledger — Lab Cycle Update
_Version: 2026-03-29af (updated from 2026-03-29ad)_
_Lab session: PROBE-EXT-001, PROBE-EXT-001b, PROBE-ZMAY-001, PROBE-TEXT-001_

---

## What changed this cycle

### New assumptions added

#### A-006 (new)
**Assumption:** Prototype knowledge (radical binding) is the dominant source of TQ2 advantage,
not the transform family alone.

**Status:** Strongly supported by PROBE-EXT-001b.

**Evidence:**
- Without prototype binding: TQ2 transform family loses to LogReg by 12–21pp on T1/T2/T4
- With prototype binding: TQ2 wins over LogReg by 11–15pp on T1/T2/T4
- Prototype knowledge gain (24–34pp) exceeds transform family contribution (~12pp)

**Revisit triggers:**
- A non-prototype-bound TQ2 variant achieves LogReg parity through better transform coverage
- Larger training set eliminates the prototype-knowledge gap

#### A-007 (new)
**Assumption:** LogReg is the correct external baseline for ternary plane data, not MLP.

**Status:** Strongly supported.

**Evidence:**
- MLP loses to LogReg by 19–42pp across T1/T2/T4
- On text tasks (PROBE-TEXT-001), MLP and LogReg are roughly tied (~19–20%)
- The large margin on geometric tasks suggests MLP non-linearities add noise to ternary structure

**Revisit triggers:**
- Larger training sets (>100 per class) where MLP can learn ternary structure effectively
- Better feature engineering that helps MLP (e.g., ternary-specific activation)

#### A-008 (new)
**Assumption:** The MAYBE family should be treated as an abstention/OOD signal,
not a first-class competitive routing target.

**Status:** Supported by PROBE-ZMAY-001.

**Evidence:**
- Ablating z_MAYBE improves routing for all other families (HI +5.5pp, YES +3.5pp, etc.)
- MAYBE prototype overlaps with other families by semantic design
- This matches the OOD abstention architecture from the calibrated abstention probe series

**Revisit triggers:**
- A richer MAYBE prototype designed to be maximally orthogonal to other families achieves
  clean competitive routing

#### A-009 (new)
**Assumption:** Geometric transforms (rotation, reflection, cyclic shift) are inappropriate
for text-encoded ternary planes.

**Status:** Supported.

**Evidence:**
- On text tasks: BASE-0 (no transforms) beats RB-2A (geometric transforms) by 3.82pp
- On geometric tasks: RB-2A (geometric transforms) dominates BASE-0 by 41.41pp
- The same transform family that helps on spatial motif tasks hurts on text routing
- Text structure is sequential/positional; geometric transforms scramble it

**Revisit triggers:**
- A text-specific transform family (n-gram proximity, prefix/suffix order) outperforms
  geometric transforms on text routing
- Better text encoding creates geometrically structured planes where rotations are meaningful

---

## New tensions logged

### T-005 (new)
**Tension:** Transform family wins on geometric tasks but loses to LogReg (−12 to −21pp)
without prototype access.

**Current best interpretation:**
The transform family provides genuine structural alignment advantage only when
the prototype is faithfully known. Without the prototype, the transforms are misapplied —
they compare test examples to poorly estimated prototypes, which may be near-zero or
inconsistent under the transform family.

**What must be revisited:**
Any claim that the transform family adds value independent of prototype binding quality.

### T-006 (new)
**Tension:** All prior text probes used MLP as external comparator. MLP loses to LogReg
by 19–42pp on ternary data. Prior conclusions about text domain performance are suspect.

**Current best interpretation:**
TEXT-001 shows TQ2 with prototype binding beats LogReg on text by +2.5pp (RB-2R_v3).
The "BASE-0 paradox" in text was not a substrate failure — it was a baseline calibration error.

**What must be revisited:**
All conclusions in prior text probes (z80, nextchar v1/v2/v3/v4/v5) that used MLP
as the external comparator. These need LogReg substituted as the correct floor.

---

## New trigger classes

### R-8 — Prototype estimation quality
If a probe shows that better prototype estimation (fewer training examples → less noise)
recovers the full transform-family advantage without needing the true bound prototype:
- Revisit A-006 (prototype knowledge vs transform family decomposition)
- Explore whether Forge/distillation can produce high-quality prototype estimates

### R-9 — Text-specific transforms
If a text-appropriate transform family (n-gram proximity, positional variants) outperforms
geometric transforms on text-encoded planes:
- Revisit A-009 and open a text-transform branch (RB-2T or similar)
- Revisit whether the current transform family spec is task-universal

---

## Updated isomorph register

### P-004 (new)
Prototype binding ↔ key-value memory ↔ exemplar-based retrieval
Shared invariant: classification quality is bottlenecked by reference quality.
A transformer's key-value attention heads face the same issue as TQ2's radical prototypes:
without good keys, attention scores are uninformative regardless of the mechanism.

### P-005 (new)
MAYBE/abstention ↔ confidence-gated OOD ↔ reject option in Bayesian classification
Shared invariant: ambiguous inputs should not compete with clear-category inputs.
The correct mechanism is a threshold gate on confidence, not prototype similarity scoring.

---

## Interaction matrix updates

### I-008 (new)
**Interaction:** Prototype binding quality × transform family advantage

**Observed effect:**
- Bound prototype + transform family: wins over LogReg by 11–15pp
- Estimated prototype + transform family: loses to LogReg by 12–21pp

**Implication:**
The transform family's advantage is contingent on prototype quality.
Below a prototype quality threshold, transforms actively hurt vs. a linear classifier.

**Required revisit:**
All benchmarks that report TQ2 accuracy must distinguish bound-prototype from estimated-prototype conditions.

---

## Current document coverage (updated)

### New this cycle
- TQ2_EXT_BASELINE_PROBE_SPEC_2026-03-29af.md
- TQ2_EXT_BASELINE_REPORT_2026-03-29af.md
- TQ2_ZMAY_ABLATION_REPORT_2026-03-29af.md
- TQ2_TEXT_LOGREG_REFRAME_REPORT_2026-03-29af.md
- TQ2_CIL_REVISIT_LEDGER_2026-03-29af.md (this doc)
- TQ2_CONSOLIDATED_NEXT_STEPS_2026-03-29af.md
- TQ2_ext_baseline_2026-03-29af.csv

### Core doctrine / control (unchanged from ad)
- TQ2_UNIFIED_ONTOLOGY_v1_2026-03-29w.md
- CIL_NATIVE_MEMORY_DOCTRINE_v1_2026-03-29s.md
- PROCESS_CHECKPOINT_META_EVAL_2026-03-29u.md
- TQ2_CIL_REVISIT_LEDGER_2026-03-29ad.md (superseded by this doc)

---

## Architecture doctrine impact

### Not changed
- TQ2 canonical substrate
- CIL exact-memory substrate
- Latent-kept reasoning as live branch
- K2 fast/live lane
- K3 not a live controller

### Promoted to explicit doctrine (from implicit assumption)
- Radical binding contract is load-bearing, not cosmetic
- Prototype binding quality is a first-class variable in all benchmark interpretation
- LogReg is the correct external floor for ternary plane task evaluation

### Newly provisionally open
- Text-specific transform family (R-9 trigger class)
- MAYBE-as-abstention architecture (connects to OOD abstention series)
- Prototype estimation quality as an independent research seam (R-8 trigger class)

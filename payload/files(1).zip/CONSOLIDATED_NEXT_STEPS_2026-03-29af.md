# Consolidated Next Steps
_Version: 2026-03-29af_

## Current strongest findings (updated this cycle)

1. TQ2 canonical substrate: confirmed across T1–T4 (geometric tasks)
2. CIL exact-memory substrate: doctrine level, not yet empirically tested
3. Latent-kept reasoning: live branch (LATENT_VERIFY_DECODE matches PER_STEP at 0.492 cost)
4. K2 reuse: current operating band; monotonic route separability accumulation confirmed
5. K3: not a live controller; summary/cold-state role still open
6. Prototype binding is load-bearing: transform family loses to LogReg without it (NEW)
7. LogReg is the correct external baseline, not MLP (NEW)
8. z_MAYBE is a noise injector; should be redesigned as abstention trigger (NEW)
9. Geometric transforms are inappropriate for text-encoded planes (NEW)
10. Multi-path collapse under K2 remains unresolved (OPEN, URGENT)
11. Dual-head readout: likely implementation defect, not informative result (OPEN)

## Immediate next tests (priority ordered)

### Priority 1 — Dual-head implementation post-mortem and retest
The dual-head producing identical results to FAMILY_ONLY is almost certainly an
implementation defect. Before concluding anything about readout disentangling:
- Audit whether the two heads are reading from structurally different latent dimensions
- Rebuild with dimension-selective projection using stepwise separability gradient
- Time the route head activation to post-step-3 (where K2 route sep peaks)
- Run specifically on the multi-path benchmark

### Priority 2 — Multi-path collapse stepwise analysis
The most important unresolved failure: K2 drops from 52.08% to 30.90% on multi-path.
Per-step decode doesn't fail as severely.
Required probe: run multi-path benchmark with stepwise route separability measurement.
If separability starts high and collapses as steps accumulate → K2 over-commits.
If separability starts low and never builds → multi-path initializes in a different regime.

### Priority 3 — LATENT_FINAL_ONLY rerun with larger N
The highest accuracy result in the corpus (82.22%) was on n=45.
Rerun with N≥200. If it holds, LATENT_FINAL_ONLY becomes the strongest evidence
for latent-kept reasoning as a viable paradigm.

### Priority 4 — MAYBE-as-abstention architecture test
Replace z_MAYBE as a competitive routing target with a confidence-threshold abstention gate.
Route MAYBE when max(family_scores) < threshold rather than when MAYBE prototype wins.
Compare with current competitive MAYBE scoring on the 5-class routing task.

### Priority 5 — Text-specific transform family probe
Design a text-appropriate transform variant:
- n-gram proximity matching (treat adjacent trigrams as equivalent)
- prefix/suffix order variants (left-shift vs right-shift of n-gram encoding)
Compare against current geometric transforms on text routing.
This would open a new branch: RB-2T (text-domain TQ2 variant).

### Priority 6 — Prototype estimation quality sweep
Probe: how does TQ2 advantage over LogReg degrade as training set size decreases?
Run T1 with N_per_class = 5, 10, 20, 50, 100.
Find the crossover point where TQ2 (no-proto) matches or beats LogReg.
This maps the "prototype quality threshold" below which transforms actively hurt.

### Priority 7 — Any distillation result (Project A)
The RB-5 branch has zero empirical grounding.
Minimum viable test: train a small logistic regression on external data, extract
its decision boundaries as a ternary prototype set, and compare classification accuracy.
Even a negative result would be informative.

### Priority 8 — Realistic longer-chain tasks
The chain-length sweep used cycled synthetic sequences.
Run on non-cycled tasks where the sequence has genuine depth.
Check whether K2 route separability monotonic accumulation holds on natural depth.

## Medium priority (after above)

- Bridge / hot-cold memory tests (K3 in cold-state/retrieval role)
- T5 symbolic sequence + T6 associative recall (benchmark harness spec completion)
- White paper update to reflect prototype-binding as first-class doctrine

## What is NOT next
- More adaptive collapse tuning (blocked by dual-head post-mortem and readout seam)
- More K3 live-control variants (settled: K3 not in live loop except cold-state)
- More MLP text probes (MLP confirmed as wrong baseline; redirect to LogReg)

# Research Lab Index
_Version: 2026-03-29af_

## Current cycle new documents

| File | Type | Status |
|---|---|---|
| TQ2_EXT_BASELINE_PROBE_SPEC_2026-03-29af.md | Spec | Complete |
| TQ2_EXT_BASELINE_REPORT_2026-03-29af.md | Report | Complete |
| TQ2_ext_baseline_2026-03-29af.csv | Data | Complete |
| TQ2_ZMAY_ABLATION_REPORT_2026-03-29af.md | Report | Complete |
| TQ2_TEXT_LOGREG_REFRAME_REPORT_2026-03-29af.md | Report | Complete |
| TQ2_CIL_REVISIT_LEDGER_2026-03-29af.md | Control | Active |
| CONSOLIDATED_NEXT_STEPS_2026-03-29af.md | Control | Active |
| WEIGHT_SUBSTRATE_WHITE_PAPER_v1.1_2026-03-29af.md | White paper | Active |
| RESEARCH_LAB_INDEX_2026-03-29af.md | Index | Active |
| tq2_substrate.py | Implementation | Reference semantics |

## Critical open probes (not yet run)

| Probe | Priority | Blocking |
|---|---|---|
| Dual-head post-mortem + retest | 1 | Route readout conclusion |
| Multi-path collapse stepwise analysis | 2 | K2 doctrine finalization |
| LATENT_FINAL_ONLY larger-N rerun | 3 | Strongest latent-kept result |
| MAYBE-as-abstention architecture | 4 | ZMAY finding action |
| Text-specific transform family | 5 | Text domain viability |
| Prototype estimation sweep | 6 | A-006 refinement |
| Any RB-5 distillation result | 7 | Project A empirical grounding |

## Settled this cycle

| Finding | Probe | Direction |
|---|---|---|
| Transform family LOSES to LogReg without prototype | EXT-001b | Settled |
| Prototype binding is load-bearing | EXT-001b | Settled |
| LogReg > MLP on ternary data (by 19–42pp) | EXT-001 | Settled |
| MLP is wrong external baseline | EXT-001 | Settled |
| z_MAYBE is noise injector for other families | ZMAY-001 | Settled |
| MAYBE should be abstention, not competitive routing | ZMAY-001 | Settled |
| Geometric transforms inappropriate for text planes | TEXT-001 | Settled |
| BASE-0 paradox was baseline calibration error | TEXT-001 | Settled |

## Still live / unsettled

| Question | Probe needed |
|---|---|
| Multi-path collapse mechanism | Stepwise separability analysis |
| Dual-head readout (implementation or structural defect?) | Code audit + retest |
| LATENT_FINAL_ONLY at scale | Large-N rerun |
| Project A empirical viability | Any distillation result |
| Text-specific transforms | RB-2T branch probe |

# PROBE-ZMAY-001: z_MAYBE Ablation Report
_Version: 2026-03-29af_

## Results

| Condition | Acc% | Δ vs FULL |
|---|---|---|
| FULL (all 5 dims) | 21.50% | — |
| NO_MAYBE | 22.20% | +0.70pp |
| NO_YES | 20.40% | −1.10pp |
| NO_UNKNOWN | 20.20% | −1.30pp |

### Per-family breakdown

| Family | FULL | NO_MAYBE | Delta |
|---|---|---|---|
| HI | 27.5% | 33.0% | +5.5pp |
| YES | 15.0% | 18.5% | +3.5pp |
| NO | 31.5% | 36.5% | +5.0pp |
| UNKNOWN | 19.0% | 23.0% | +4.0pp |
| MAYBE | 14.5% | 0.0% | −14.5pp |

## Load-bearing findings

### F-ZMAY-001: Direction confirmed — MAYBE is a noise injector for all other families
Removing z_MAYBE improves routing accuracy for HI (+5.5pp), YES (+3.5pp),
NO (+5.0pp), and UNKNOWN (+4.0pp).
This confirms the criticality map's negative total drop score for z_MAYBE.

### F-ZMAY-002: Raw ablation is not the correct fix
When z_MAYBE is removed from the candidate set, MAYBE family accuracy drops to 0%.
Ablating z_MAYBE destroys MAYBE routing entirely.
This is not a viable intervention.

### F-ZMAY-003: MAYBE should be treated as an uncertainty/abstention signal, not a competitive family
The MAYBE family is semantically an uncertainty marker.
Its prototype overlaps significantly with other families by design.
Competing it directly against other prototypes causes cross-family interference.

## Doctrine implication

The correct fix is NOT simple ablation.
The correct fix is to treat MAYBE as an OOD/abstention signal:
- Route MAYBE inputs when no other family's confidence exceeds a threshold
- Do NOT include MAYBE as a first-class competitive scoring target in the fast lane
This connects directly to the OOD abstention work (calibrated abstention probe series).

## Required revisit

T-ZMAY-001: All probe designs that treat MAYBE as a co-equal family alongside
HI/YES/NO/UNKNOWN should be revisited.
The correct design is: {HI, YES, NO, UNKNOWN} as primary routing targets +
MAYBE as a threshold-triggered abstention class.

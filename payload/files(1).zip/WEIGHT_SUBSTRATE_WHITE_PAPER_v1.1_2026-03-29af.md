# Weight Substrate White Paper
_Version: 1.1 · 2026-03-29af_

## Executive update (v1.1)

Two major findings from the first external calibration cycle:

**Finding 1 — Prototype binding is load-bearing.**
The transform family advantage completely depends on faithful prototype binding.
Without it: TQ2 loses to LogReg by 12–21pp.
With it: TQ2 wins over LogReg by 11–15pp.
The Forge/RB-5 distillation bridge is therefore not a nice-to-have — it is the
mechanism that makes the substrate advantage real.

**Finding 2 — LogReg, not MLP, is the correct external floor.**
All prior text and sequence probes used MLP as the external comparator.
MLP loses to LogReg by 19–42pp on ternary plane data.
Conclusions from those probes about text domain performance are being revised.
The BASE-0 paradox was a baseline calibration error, not a substrate failure.

## Current best candidates (updated from v1.0)
- Canonical substrate: TQ2
- Integrated runtime candidate: RB-2R_v3 (metadata-aware mode gating, first promotable runtime)
- External calibration floor: LogReg (replaces MLP as correct comparator)
- Prototype binding: first-class research seam (required for transform family advantage)
- OOD/abstention: MAYBE family redesign as confidence-threshold abstention (not prototype-competitive)
- Text-domain: requires text-specific transform family (current geometric transforms are inappropriate)

## Architecture decomposition (new in v1.1)

The TQ2 advantage has three separable contributors:

1. **Prototype knowledge** (~24–34pp gain)
   - Comes from accurate radical binding / prototype registration
   - Without this: transform family actively hurts vs LogReg
   - This is what the Forge distillation bridge must deliver

2. **Transform family** (~12pp gain above LogReg, given prototype)
   - Comes from the cheap closed operator family (rotations, reflections, cyclic shifts)
   - Only active when the prototype is faithfully known
   - Task-specific: geometric transforms ≠ text transforms

3. **Runtime composition / mode gating** (~3–5pp gain above specialist average)
   - Comes from RB-2R_v3 regime routing (global/local/polarity/mixed)
   - Depends on both prototype quality AND appropriate transform family
   - T4 mixed task: RB-2R_v3 beats best single specialist

## Updated research branch status

| Branch | Status | Note |
|---|---|---|
| RB-2A (whole-plane) | Promoted specialist | 98.75% T1 (bound-proto) |
| RB-2B (blockwise) | Promoted specialist | 98.44% T2 (bound-proto) |
| RB-2R_v3 (integrated) | Current best runtime | T4 77.66%; T1/T2/T3 ceiling |
| RB-5 (distillation) | Zero empirical grounding | Urgent: any result needed |
| Text-specific transforms | Provisionally open | Current geometric transforms inappropriate for text |
| MAYBE-as-abstention | Provisionally open | Evidence from ZMAY-001 |
| LogReg floor | Now canonical | Replaces MLP as external comparator |

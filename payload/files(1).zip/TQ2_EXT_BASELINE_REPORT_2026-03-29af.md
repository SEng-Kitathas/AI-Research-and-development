# PROBE-EXT-001 Report — External Calibration Results
_Version: 2026-03-29af_

## Results — Full comparison

### T1 Whole-plane motif invariance
| Model | Acc% | ±σ | F1% |
|---|---|---|---|
| BASE-0 (bound) | 57.34 | 13.19 | 54.63 |
| RB-2A (bound) | 98.75 | 1.53 | 98.69 |
| RB-2B (bound) | 62.03 | 15.88 | 59.06 |
| RB-2R_v3 (bound) | 98.75 | 1.53 | 98.69 |
| MLP_64x64 | 59.84 | 19.02 | 56.03 |
| MLP_128x64 | 68.12 | 15.20 | 67.10 |
| **LogReg** | **87.03** | 11.02 | 85.89 |

### T2 Block composition invariance
| Model | Acc% | ±σ | F1% |
|---|---|---|---|
| BASE-0 (bound) | 60.31 | 12.23 | 57.97 |
| RB-2A (bound) | 61.25 | 13.64 | 57.71 |
| RB-2B (bound) | 98.44 | 2.32 | 98.35 |
| RB-2R_v3 (bound) | 98.44 | 2.32 | 98.35 |
| MLP_64x64 | 44.06 | 14.39 | 39.41 |
| MLP_128x64 | 58.12 | 12.55 | 54.65 |
| **LogReg** | **86.25** | 8.75 | 85.61 |

### T3 Majority-sign sanity
| Model | Acc% | ±σ | F1% |
|---|---|---|---|
| BASE-0 | 73.79 | 6.23 | 69.86 |
| RB-2A | 71.06 | 9.41 | 68.64 |
| RB-2B | 67.12 | 8.48 | 64.76 |
| RB-2R_v3 | 93.03 | 12.20 | 92.39 |
| MLP_64x64 | 46.67 | 12.76 | 43.28 |
| MLP_128x64 | 57.58 | 17.64 | 53.91 |
| **LogReg** | **83.03** | 8.75 | 81.85 |

### T4 Mixed global+local
| Model | Acc% | ±σ | F1% |
|---|---|---|---|
| BASE-0 | 47.50 | 15.83 | 44.30 |
| RB-2A (bound) | 73.44 | 10.89 | 71.74 |
| RB-2B (bound) | 67.03 | 15.58 | 64.29 |
| RB-2R_v3 (bound) | 77.66 | 13.84 | 76.03 |
| MLP_64x64 | 43.12 | 15.26 | 39.57 |
| MLP_128x64 | 32.34 | 11.62 | 29.06 |
| **LogReg** | **62.50** | 14.66 | 61.33 |

## Results — Decomposition (PROBE-EXT-001b)

| Task | Proto gain | XForm vs LogReg | Full TQ2 vs LogReg | Linear vs MLP |
|---|---|---|---|---|
| T1 | +24.22pp | −12.50pp | +11.72pp | +27.19pp |
| T2 | +33.60pp | −21.41pp | +12.19pp | +42.19pp |
| T4 | +24.53pp | −13.59pp | +10.94pp | +19.38pp |

## Load-bearing findings

### F-001: Transform family LOSES to LogReg without prototype binding
On every task, the no-prototype TQ2 model underperforms LogReg by 12–21pp.
The transform family, without the radical prototype bound to it, adds no
value over a simple linear classifier.

### F-002: Transform family WINS over LogReg when prototype is bound
With the true prototype, RB-2A beats LogReg by +11.72pp on T1.
RB-2B beats LogReg by +12.19pp on T2.
RB-2R_v3 beats LogReg by +15.16pp on T4.
The transform family is doing real work, but only when the prototype is known.

### F-003: Prototype knowledge is the dominant contributor (~24–34pp)
Prototype binding contributes more than the transform family in every case.
This means the radical binding contract is load-bearing, not cosmetic.
Without faithful prototype estimation or distillation, the substrate advantage disappears.

### F-004: LogReg is the correct external baseline, not MLP
MLP consistently underperforms LogReg by 19–42pp on ternary plane data.
Using MLP as the external comparator has been producing misleading comparisons.
All prior text-domain work compared against wrong baseline level.
LogReg is the correct floor for "what a non-transform learned classifier achieves."

### F-005: Linear beats nonlinear on ternary plane data (large margin)
The +27pp / +42pp / +19pp LogReg advantage over MLP across T1/T2/T4 is striking.
Possible explanations:
  (a) 9-dim ternary features create roughly linear decision boundaries by structure
  (b) MLP non-linearities introduce spurious interactions in small-N regimes
  (c) The structured ternary space is incompatible with learned non-linear feature extraction
This finding is consistent with TQ2's design philosophy (structured composition > scalar approximation).

## Immediate doctrine impact

### I-006 (new)
The text-domain BASE-0 paradox must be reframed.
Prior comparisons used MLP as the external baseline.
MLP underperforms LogReg by 19–42pp on ternary data.
The correct question is not "why does BASE-0 beat MLP" but
"why does TQ2 not beat LogReg without prototype binding on text tasks."

### I-007 (new)
Prototype binding is now a first-class research seam, not assumed infrastructure.
Any benchmark result that uses bound prototypes must explicitly label this.
Results without prototype binding are a separate and weaker condition.

## Caveats
- Task generators may diverge slightly from original benchmarks (T3 and T4 show different absolute numbers from target)
- Qualitative patterns for T1 and T2 match well (within ±2pp of targets)
- Protocol matches existing lab: 20 seeds, 80 samples, 60/40 split
- MLP uses early stopping; results may vary with different stopping criteria

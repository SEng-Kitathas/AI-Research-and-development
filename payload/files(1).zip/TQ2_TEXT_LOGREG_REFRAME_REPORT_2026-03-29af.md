# PROBE-TEXT-001: Text Routing with Correct External Baseline
_Version: 2026-03-29af_

## Context
All prior text-domain probes used MLP as the external comparator.
PROBE-EXT-001 established that MLP loses to LogReg by 19–42pp on ternary plane data.
This probe reruns text intent routing with LogReg as the correct external baseline.

## Results

| Model | Acc% | ±σ |
|---|---|---|
| BASE-0 (bound) | 26.47 | 0.00 |
| RB-2A (bound) | 22.65 | 4.68 |
| RB-2B (bound) | 19.61 | 2.50 |
| RB-2R_v3 (bound) | 21.62 | 4.07 |
| **LogReg** | **19.12** | 0.00 |
| MLP_64x64 | 20.44 | 3.53 |

RB-2R_v3 vs LogReg: +2.50pp
BASE-0 vs LogReg: +7.35pp
LogReg vs MLP: −1.32pp (on text, MLP barely edges LogReg)

## Load-bearing findings

### F-TEXT-001: BASE-0 paradox is resolved — wrong baseline was used
Prior work compared BASE-0 against MLP, found MLP was competitive or winning.
Conclusion was: "the substrate isn't adding value on text tasks."
Correct conclusion: MLP is the wrong baseline for ternary plane data.
With LogReg as the correct floor: ALL TQ2 models with prototype binding beat or match
the correct external baseline.

### F-TEXT-002: BASE-0 beats more complex TQ2 models on text routing
On text, BASE-0 (26.47%) > RB-2A (22.65%) > RB-2R_v3 (21.62%) > RB-2B (19.61%).
This is the opposite of the geometric task ordering.
Interpretation: geometric transforms (rotations, reflections, cyclic shifts) applied to
text-encoded ternary planes are INAPPROPRIATE transforms.
Text-encoded planes are not geometrically invariant — rotating a trigram hash plane
scrambles the semantic structure rather than revealing it.

### F-TEXT-003: Absolute accuracy across all models is low (~20–27%)
This is the encoder bottleneck.
The trigram hash encoding is too lossy for 5-class intent disambiguation.
TQ2 advantage over LogReg is real but small (+2.5pp).
The dominant improvement path is encoder quality, not runtime architecture.

### F-TEXT-004: Text domain needs text-appropriate transforms, not geometric ones
Applying rotation/reflection to text-encoded planes is likely harmful.
The correct transform family for text-encoded inputs would be:
- n-gram proximity matching
- prefix/suffix order variants
- character-level edit-distance weighting
These are not the current TQ2 transform family.

## Doctrine update

The text domain requires a different transform family than the geometric domain.
Current TQ2 transforms (rotations, reflections, cyclic shifts) are designed for
spatial/motif invariants.
Text invariants are sequential and positional, not geometric.
Two options:
A. Design text-specific transform variants (new branch)
B. Accept that TQ2's text advantage comes from prototype binding quality, not transforms
